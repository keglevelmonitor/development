## Hardware Requirements


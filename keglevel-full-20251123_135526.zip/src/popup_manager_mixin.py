# keglevel app
#
# popup_manager_mixin.py
import tkinter as tk
from tkinter import ttk, messagebox
import tkinter.font as tkfont 
import math
import time
import queue
import os
import uuid 
import subprocess 
import sys      
import re
import threading

# --- NEW: EULA/Support Imports ---
import tkinter.scrolledtext as scrolledtext
import webbrowser
# --- END NEW ---

# --- NEW: Import manage_autostart_file from main.py ---
from main import manage_autostart_file
# --- END NEW IMPORT ---

# --- NEW: Import ProcessFlowApp for in-process hosting ---
# Removing mock for ProcessFlowApp is not feasible here as it needs to run 
# in the environment if the import fails, so the conditional import is necessary.
try:
    from process_flow import ProcessFlowApp 
except ImportError:
    class ProcessFlowApp:
        def __init__(self, root_window, settings_manager, base_dir, parent_root=None): pass
        def run(self): print("ProcessFlowApp mock run.")

# --- NEW: Import platform flag from sensor_logic ---\
# FIX: IS_RASPBERRY_PI_MODE is still needed, keep import.
from sensor_logic import IS_RASPBERRY_PI_MODE
# ------------------------------------

LITERS_TO_GALLONS = 0.264172
KG_TO_LB = 2.20462
# CONSTANT: Ratio of US Fluid Ounces to Liters
OZ_TO_LITERS = 0.0295735

# --- MIXIN CLASS: Contains all settings/popup logic ---
class PopupManagerMixin:    
    def __init__(self, settings_manager_instance, num_sensors, app_version_string=None):
        self.settings_manager = settings_manager_instance
        self.num_sensors = num_sensors
        self.base_dir = os.path.dirname(os.path.abspath(__file__)) 
        
        # --- Version Calculation (Unchanged) ---
        version_source = app_version_string if app_version_string else 'Unknown (Script Model)'
        try:
            executable_path = sys.argv[0]
            filename = os.path.basename(executable_path)
            match = re.search(r'KegLevel_Monitor_(\d{12})', filename)
            if match:
                datecode = match.group(1)
                year, month, day, hour, minute = datecode[0:4], datecode[4:6], datecode[6:8], datecode[8:10], datecode[10:12]
                version_source = f"{datecode} (Compiled: {year}-{month}-{day} {hour}:{minute})"
        except Exception:
            version_source = "Unknown (Error during startup parsing)"
        self.app_version_string = version_source 
        
        # --- Settings Popup Variables ---
        self.beverage_popup_vars = [] 
        self.keg_settings_popup_vars = [] 
        
        # System Settings
        self.system_settings_unit_var = tk.StringVar()
        self.system_settings_taps_var = tk.StringVar()
        self.system_settings_ui_mode_var = tk.StringVar()
        self.system_settings_temp_unit_label = tk.StringVar() 
        self.sensor_ambient_var = tk.StringVar()
        
        self.system_settings_autostart_var = tk.BooleanVar() 
        self.system_settings_launch_workflow_var = tk.BooleanVar() 

        self.system_settings_pour_ml_var = tk.StringVar()
        self.system_settings_pour_oz_var = tk.StringVar()
        
        # --- UPDATED: Messaging Settings Variables ---
        # Checkbox Booleans
        self.msg_push_enabled_var = tk.BooleanVar()
        self.msg_conditional_enabled_var = tk.BooleanVar()
        self.status_req_enable_var = tk.BooleanVar() # Reused from previous, but now part of main UI

        # Configuration Strings
        self.msg_frequency_var = tk.StringVar()
        self.msg_server_email_var = tk.StringVar()
        self.msg_server_password_var = tk.StringVar()
        self.msg_email_recipient_var = tk.StringVar()
        self.msg_smtp_server_var = tk.StringVar()
        self.msg_smtp_port_var = tk.StringVar()
        
        # IMAP Config (for Status Request)
        self.status_req_sender_var = tk.StringVar() # Authorized Sender
        self.status_req_imap_server_var = tk.StringVar()
        self.status_req_imap_port_var = tk.StringVar()
        
        # Conditional Thresholds
        self.msg_conditional_threshold_var = tk.StringVar()
        self.msg_conditional_threshold_units_var = tk.StringVar(value="Gallons")
        self.last_units_for_threshold = self.settings_manager.get_display_units()
        self.msg_conditional_threshold_label_text = tk.StringVar()
        self.msg_conditional_low_temp_var = tk.StringVar()
        self.msg_conditional_high_temp_var = tk.StringVar()
        
        # --- Flow Calibration Variables ---
        self.flow_cal_current_factors = [tk.StringVar() for _ in range(self.num_sensors)]
        self.flow_cal_new_factor_entries = [tk.StringVar() for _ in range(self.num_sensors)]
        self.flow_cal_notes_var = tk.StringVar()
        self.single_cal_target_volume_var = tk.StringVar()
        self.single_cal_measured_flow_var = tk.StringVar(value="0.00 L/min")
        self.single_cal_measured_pour_var = tk.StringVar(value="0.00")
        self.single_cal_unit_label = tk.StringVar()
        self.single_cal_tap_index = -1
        self.single_cal_current_factor_var = tk.StringVar() 
        self.single_cal_new_factor_var = tk.StringVar()      
        self._single_cal_calculated_new_factor = None        
        self.single_cal_deduct_volume_var = tk.BooleanVar(value=False)

        self._single_cal_in_progress = False
        self._single_cal_complete = False
        self._single_cal_pulse_count = 0
        self._single_cal_last_pour = 0.0
        self._single_cal_popup_window = None 

        # --- EULA/Support Popup Variables ---
        self.eula_agreement_var = tk.IntVar(value=0) 
        self.show_eula_checkbox_var = tk.BooleanVar()
        self.support_qr_image = None


    # --- Status Request Settings Popup Logic (NEW) ---
    def _open_message_settings_popup(self):
        popup = tk.Toplevel(self.root)
        
        # --- FIX: Hide immediately to prevent "Jump/Flash" visual glitch ---
        popup.withdraw() 
        
        popup.title("Notification Settings")
        popup.transient(self.root)
        popup.grab_set()
        
        form_frame = ttk.Frame(popup, padding="5")
        form_frame.pack(expand=True, fill="both")
        
        # --- FETCH SETTINGS ---
        push_notif_settings = self.settings_manager.get_push_notification_settings()
        cond_notif_settings = self.settings_manager.get_conditional_notification_settings()
        status_req_settings = self.settings_manager.get_status_request_settings()
        display_units = self.settings_manager.get_display_units()
        
        # --- INITIALIZE VARIABLES ---
        
        # 1. Push Logic
        push_type = push_notif_settings.get('notification_type', 'None')
        self.msg_push_enabled_var.set(push_type != 'None')
        self.msg_frequency_var.set(push_notif_settings.get('frequency', 'Daily'))
        
        # Shared Recipient
        self.msg_email_recipient_var.set(push_notif_settings.get('email_recipient', ''))

        # 2. Conditional Logic
        cond_type = cond_notif_settings.get('notification_type', 'None')
        self.msg_conditional_enabled_var.set(cond_type != 'None')
        
        # Initialize Thresholds (Unit Conversion)
        cond_threshold_liters = cond_notif_settings.get('threshold_liters')
        if display_units == "imperial":
            threshold_value = cond_threshold_liters * LITERS_TO_GALLONS if cond_threshold_liters is not None else None
            self.msg_conditional_threshold_var.set(f"{threshold_value:.2f}" if threshold_value is not None else "")
            self.msg_conditional_threshold_units_var.set("Gallons")
        else:
            self.msg_conditional_threshold_var.set(f"{cond_threshold_liters:.2f}" if cond_threshold_liters is not None else "")
            self.msg_conditional_threshold_units_var.set("Liters")

        low_temp_f = cond_notif_settings.get('low_temp_f'); high_temp_f = cond_notif_settings.get('high_temp_f')
        if display_units == "imperial":
            self.msg_conditional_low_temp_var.set(f"{low_temp_f:.1f}" if low_temp_f is not None else "")
            self.msg_conditional_high_temp_var.set(f"{high_temp_f:.1f}" if high_temp_f is not None else "")
        else:
            low_temp_c = (low_temp_f - 32) * (5/9) if low_temp_f is not None else None
            high_temp_c = (high_temp_f - 32) * (5/9) if high_temp_f is not None else None
            self.msg_conditional_low_temp_var.set(f"{low_temp_c:.1f}" if low_temp_c is not None else "")
            self.msg_conditional_high_temp_var.set(f"{high_temp_c:.1f}" if high_temp_f is not None else "")

        # 3. Status Request Logic
        self.status_req_enable_var.set(status_req_settings.get('enable_status_request', False))
        self.status_req_sender_var.set(status_req_settings.get('authorized_sender', ''))

        # 4. RPi Config
        self.msg_server_email_var.set(push_notif_settings.get('server_email', ''))
        self.msg_server_password_var.set(push_notif_settings.get('server_password', ''))
        self.msg_smtp_server_var.set(push_notif_settings.get('smtp_server', ''))
        
        smtp_port_val = push_notif_settings.get('smtp_port', '')
        self.msg_smtp_port_var.set(str(smtp_port_val) if isinstance(smtp_port_val, int) else '')
        
        self.status_req_imap_server_var.set(status_req_settings.get('imap_server', ''))
        
        imap_port_val = status_req_settings.get('imap_port', '')
        self.status_req_imap_port_var.set(str(imap_port_val) if isinstance(imap_port_val, int) else '')

        # --- HELPER FOR ROWS ---
        def add_row(parent_frame, label_text, string_var, show_char=None, is_dropdown=False, options=None):
            row_frame = ttk.Frame(parent_frame); row_frame.pack(fill="x", pady=2)
            ttk.Label(row_frame, text=label_text, width=25, anchor='w').pack(side="left", padx=(5, 5))
            
            widget = None
            if is_dropdown:
                widget = ttk.Combobox(row_frame, textvariable=string_var, values=options, state="readonly", width=30)
            else:
                widget = ttk.Entry(row_frame, textvariable=string_var, width=30, show=show_char)
            widget.pack(side="left", fill="x", expand=True)
            return widget

        # --- BUILD UI (NOTEBOOK) ---
        notebook = ttk.Notebook(form_frame)
        notebook.pack(expand=True, fill='both', padx=5, pady=5)

        # Tab 1: Alerts & Controls
        tab1 = ttk.Frame(notebook, padding=10)
        notebook.add(tab1, text='Alerts & Controls')

        # Tab 2: RPi Email Configuration
        tab2 = ttk.Frame(notebook, padding=10)
        notebook.add(tab2, text='RPi Email Configuration')
        
        # ============================================================
        # TAB 1: ALERTS & CONTROLS
        # ============================================================
        
        # Section A: Outbound Alerts
        outbound_frame = ttk.LabelFrame(tab1, text="Outbound Alerts (Push & Conditional)", padding=10)
        outbound_frame.pack(fill='x', pady=(0, 10))
        
        # 1. Recipient
        self.shared_recipient_entry = add_row(outbound_frame, "Recipient Email:", self.msg_email_recipient_var)
        ttk.Label(outbound_frame, text="(Required if either Push or Conditional notifications are enabled)", 
                  font=('TkDefaultFont', 8, 'italic')).pack(anchor='w', padx=25, pady=(0, 10))

        # 2. Push Notifications
        self.push_check = ttk.Checkbutton(outbound_frame, text="Enable Push Notifications", variable=self.msg_push_enabled_var)
        self.push_check.pack(anchor='w', pady=(0, 2))
        
        push_notes = "E.g. Daily status reports sent at a fixed interval."
        ttk.Label(outbound_frame, text=push_notes, font=('TkDefaultFont', 8, 'italic'), wraplength=500).pack(anchor='w', padx=25, pady=(0, 5))
        
        freq_frame = ttk.Frame(outbound_frame); freq_frame.pack(fill='x', padx=25, pady=(0, 10))
        ttk.Label(freq_frame, text="Report Frequency:", width=20, anchor='w').pack(side='left')
        self.freq_dropdown = ttk.Combobox(freq_frame, textvariable=self.msg_frequency_var, 
                                          values=["Hourly", "Daily", "Weekly", "Monthly"], state="readonly", width=20)
        self.freq_dropdown.pack(side='left')

        # 3. Conditional Notifications
        self.cond_check = ttk.Checkbutton(outbound_frame, text="Enable Conditional Notifications", variable=self.msg_conditional_enabled_var)
        self.cond_check.pack(anchor='w', pady=(0, 2))
        
        # Conditional Fields
        cond_options_frame = ttk.Frame(outbound_frame); cond_options_frame.pack(fill="x", padx=25, pady=(0, 0))

        # Volume Row
        self.cond_vol_frame = ttk.Frame(cond_options_frame); self.cond_vol_frame.pack(fill="x", pady=2)
        ttk.Label(self.cond_vol_frame, text="Notify when tap volume <", width=24).pack(side="left", padx=(5,0))
        self.cond_vol_entry = ttk.Entry(self.cond_vol_frame, textvariable=self.msg_conditional_threshold_var, width=8)
        self.cond_vol_entry.pack(side="left")
        ttk.Label(self.cond_vol_frame, textvariable=self.msg_conditional_threshold_units_var).pack(side="left", padx=(5, 5))

        # Temp Row
        self.cond_temp_frame = ttk.Frame(cond_options_frame); self.cond_temp_frame.pack(fill="x", pady=2)
        unit_char = "F" if display_units == "imperial" else "C"
        ttk.Label(self.cond_temp_frame, text=f"Notify when Temp outside:", width=24).pack(side="left", padx=(5,0))
        self.cond_low_entry = ttk.Entry(self.cond_temp_frame, textvariable=self.msg_conditional_low_temp_var, width=6)
        self.cond_low_entry.pack(side="left")
        ttk.Label(self.cond_temp_frame, text=f" - ").pack(side="left")
        self.cond_high_entry = ttk.Entry(self.cond_temp_frame, textvariable=self.msg_conditional_high_temp_var, width=6)
        self.cond_high_entry.pack(side="left")
        ttk.Label(self.cond_temp_frame, text=f"{unit_char}").pack(side="left", padx=(5, 5))

        # Section B: Inbound Controls
        inbound_frame = ttk.LabelFrame(tab1, text="Inbound Controls (Status & Commands)", padding=10)
        inbound_frame.pack(fill='x', pady=10)

        self.req_check = ttk.Checkbutton(inbound_frame, text="Enable Email Control (Status & Commands)", variable=self.status_req_enable_var)
        self.req_check.pack(anchor='w', pady=(0, 5))
        
        warning_text_tab1 = (
            "WARNING: When enabled, the app checks the 'RPi Email Configuration' account for new messages "
            "from the Authorized Sender. If new messages exist, the app marks them as 'read', and "
            "processes them for 'Status' or 'Command' actions. Only enable this feature if you are using "
            "a dedicated email account set up exclusively for this app, and enter that email account's "
            "configuration settings on the 'RPi Email Configuration' tab."
        )
        ttk.Label(inbound_frame, text=warning_text_tab1, font=('TkDefaultFont', 8, 'italic'), wraplength=550, justify='left').pack(anchor='w', padx=20, pady=(0, 5))

        auth_frame = ttk.Frame(inbound_frame); auth_frame.pack(fill='x', padx=20)
        ttk.Label(auth_frame, text="Authorized Sender:", width=20, anchor='w').pack(side='left')
        self.req_sender_entry = ttk.Entry(auth_frame, textvariable=self.status_req_sender_var, width=35)
        self.req_sender_entry.pack(side='left', fill='x', expand=True)

        # ============================================================
        # TAB 2: RPi CONFIG
        # ============================================================
        
        warning_text_tab2 = (
            "WARNING: When Email Control is enabled, the app checks the 'RPi Email Configuration' account for new messages "
            "from the Authorized Sender. If new messages exist, the app marks them as 'read', and "
            "processes them for 'Status' or 'Command' actions. Only enable this feature if you are using "
            "a dedicated email account set up exclusively for this app, and enter that email account's "
            "configuration settings on the 'RPi Email Configuration' tab."
        )
        ttk.Label(tab2, text=warning_text_tab2, font=('TkDefaultFont', 8, 'italic'), wraplength=550, justify='left').pack(anchor='w', pady=(0, 15))

        self.rpi_email_entry = add_row(tab2, "RPi Email Address:", self.msg_server_email_var)
        self.rpi_password_entry = add_row(tab2, "RPi Email Password:", self.msg_server_password_var, show_char="*")
        ttk.Separator(tab2, orient='horizontal').pack(fill='x', pady=10)
        self.smtp_server_entry = add_row(tab2, "SMTP (Outgoing) Server:", self.msg_smtp_server_var)
        self.smtp_port_entry = add_row(tab2, "SMTP (Outgoing) Port:", self.msg_smtp_port_var)
        ttk.Separator(tab2, orient='horizontal').pack(fill='x', pady=10)
        self.imap_server_entry = add_row(tab2, "IMAP (Incoming) Server:", self.status_req_imap_server_var)
        self.imap_port_entry = add_row(tab2, "IMAP (Incoming) Port:", self.status_req_imap_port_var)

        # --- BUTTONS ---
        btns_frame = ttk.Frame(popup, padding="10"); btns_frame.pack(fill="x", side="bottom")
        ttk.Button(btns_frame, text="Save", command=lambda: self._save_message_settings(popup)).pack(side="right", padx=5)
        ttk.Button(btns_frame, text="Cancel", command=popup.destroy).pack(side="right", padx=5)
        # NEW HELP BUTTON
        ttk.Button(btns_frame, text="Help", width=8,
                   command=lambda: self._open_help_popup("notifications")).pack(side="right", padx=5)

        # --- TRACES ---
        self.msg_push_enabled_var.trace_add("write", self._toggle_email_fields_state)
        self.msg_conditional_enabled_var.trace_add("write", self._toggle_email_fields_state)
        self.status_req_enable_var.trace_add("write", self._toggle_email_fields_state)
        
        self._toggle_email_fields_state()
        
        # Center with calculated dimensions (Width=650, Height=550)
        self._center_popup(popup, 650, 550)
        
        
    def _save_status_request_settings(self, popup_window):
        # 1. Validation
        if self.status_req_enable_var.get():
            fields_to_check = [
                (self.status_req_sender_var, "Authorized Sender"),
                (self.status_req_rpi_email_var, "RPi Email"),
                (self.status_req_rpi_password_var, "RPi Password"),
                (self.status_req_imap_server_var, "IMAP Server"),
                (self.status_req_imap_port_var, "IMAP Port"),
                (self.status_req_smtp_server_var, "SMTP Server"),
                (self.status_req_smtp_port_var, "SMTP Port")
            ]
            
            for var, name in fields_to_check:
                if not var.get().strip():
                    messagebox.showerror("Input Error", f"Enabling Status Request requires the '{name}' field to be filled.", parent=popup_window)
                    return
            
            try:
                if not (0 < int(self.status_req_imap_port_var.get().strip()) <= 65535):
                    messagebox.showerror("Input Error", "IMAP Port must be 1-65535.", parent=popup_window)
                    return
                if not (0 < int(self.status_req_smtp_port_var.get().strip()) <= 65535):
                    messagebox.showerror("Input Error", "SMTP Port must be 1-65535.", parent=popup_window)
                    return
            except ValueError:
                messagebox.showerror("Input Error", "IMAP/SMTP Port must be valid numbers.", parent=popup_window)
                return

        # 2. Compile settings dict (port variables are saved as strings/empty strings if not integer)
        new_settings = {
            "enable_status_request": self.status_req_enable_var.get(),
            "authorized_sender": self.status_req_sender_var.get().strip(),
            "rpi_email_address": self.status_req_rpi_email_var.get().strip(),
            "rpi_email_password": self.status_req_rpi_password_var.get(),
            "imap_server": self.status_req_imap_server_var.get().strip(),
            "imap_port": self.status_req_imap_port_var.get().strip(), # Saved as string, converted to int/"" by SettingsManager
            "smtp_server": self.status_req_smtp_server_var.get().strip(),
            "smtp_port": self.status_req_smtp_port_var.get().strip() # Saved as string, converted to int/"" by SettingsManager
        }

        # 3. Save and trigger reschedule
        self.settings_manager.save_status_request_settings(new_settings)
        
        if hasattr(self, 'notification_service') and self.notification_service: 
            # This handles stopping the old thread and starting the new one if enabled/disabled
            self.notification_service.force_reschedule() 
        
        print("UIManager: Status Request settings saved.")
        popup_window.destroy()
        
    # --- END Status Request Settings Popup Logic ---

    # --- Popup Implementations ---

    def _open_workflow_popup(self):
        try:
            workflow_window = tk.Toplevel(self.root)
            workflow_window.title("KegLevel Workflow")
            workflow_window.transient(self.root)
            
            ui_mode = self.settings_manager.get_ui_mode()
            is_full_mode = (ui_mode == 'full')

            if is_full_mode:
                WORKFLOW_WIDTH, WORKFLOW_HEIGHT, X_POS, Y_POS = 1920, 564, 0, 522
                workflow_window.geometry(f"{WORKFLOW_WIDTH}x{WORKFLOW_HEIGHT}+{X_POS}+{Y_POS}")
                workflow_window.resizable(True, True) 
            else:
                W, H = 700, 600
                X, Y = 0, 72 
                workflow_window.geometry(f"{W}x{H}+{X}+{Y}")
                workflow_window.resizable(False, False)

            self.workflow_app = ProcessFlowApp(
                root_window=workflow_window, 
                settings_manager=self.settings_manager, 
                base_dir=self.base_dir, 
                parent_root=self.root 
            )
            
            self.workflow_app.run() 
            
            if not IS_RASPBERRY_PI_MODE:
                messagebox.showinfo("Workflow Launched", 
                                    "KegLevel Workflow has been launched in a separate window. "
                                    "If not immediately visible, please check your taskbar.", 
                                    parent=self.root)

        except Exception as e:
            messagebox.showerror("Launch Error", f"Could not launch Workflow UI in-process:\n{e}", parent=self.root)
            if 'workflow_window' in locals() and workflow_window.winfo_exists():
                 workflow_window.destroy()
                 
    def _open_update_status_popup(self, popup, on_complete_callback):
        """
        Opens the intermediate dialog to show the update script's output.
        This is based on the FermVault implementation.
        MODIFIED: Accepts an on_complete_callback to fix race condition.
        """
        # Create a queue to send stdout lines from the thread to the UI
        update_queue = queue.Queue()
        
        # Create the popup
        status_popup = tk.Toplevel(self.root)
        status_popup.title("Checking for Updates...")
        status_popup.geometry("600x400")
        status_popup.transient(self.root)
        status_popup.grab_set()

        # Create a ScrolledText widget
        text_area = scrolledtext.ScrolledText(status_popup, wrap=tk.WORD, height=20, width=80)
        text_area.pack(padx=10, pady=10, fill="both", expand=True)
        text_area.insert(tk.END, "Starting update check...\n")
        text_area.insert(tk.END, "This may take a moment. Please wait for the script to finish.\n")
        text_area.insert(tk.END, "--------------------------------------------------\n")
        text_area.config(state="disabled")

        # Create a close button (initially disabled)
        close_button = ttk.Button(status_popup, text="Close", state="disabled")
        close_button.pack(pady=(0, 10))
        
        def check_queue():
            """Polls the queue for new messages from the update thread."""
            try:
                while True:
                    line = update_queue.get_nowait()
                    if line is None: # End signal
                        close_button.config(state="normal")
                        status_popup.title("Update Check Finished")
                        
                        # --- FIX: Trigger the callback function ---
                        if on_complete_callback:
                            on_complete_callback(status_popup) # Pass popup to the callback
                        # --- END FIX ---
                        return # Stop polling
                    
                    text_area.config(state="normal")
                    text_area.insert(tk.END, line)
                    text_area.see(tk.END)
                    text_area.config(state="disabled")
                    
            except queue.Empty:
                pass # No new messages
            
            status_popup.after(100, check_queue)

        # Start polling the queue
        status_popup.after(100, check_queue)

        # Make the close button work
        close_button.config(command=status_popup.destroy)

        return update_queue, status_popup

    def _read_update_output(self, process, queue_, shared_output_list):
        """
        Thread target function: Reads stdout from the subprocess
        and puts it on the queue.
        MODIFIED: Now stores full output in a shared list to avoid race conditions.
        """
        full_output = ""
        try:
            # Read stdout line by line in real-time
            for line in iter(process.stdout.readline, ''):
                queue_.put(line) # Put line for UI
                full_output += line
            
            process.stdout.close()
            return_code = process.wait()
            
            if return_code != 0:
                stderr_output = process.stderr.read()
                error_lines = f"\n--- SCRIPT ERROR ---\nReturn Code: {return_code}\n{stderr_output}"
                queue_.put(error_lines) # Put error for UI
                full_output += error_lines
                
        except Exception as e:
            error_lines = f"\n--- PYTHON ERROR ---\nError reading script output: {e}\n"
            queue_.put(error_lines) # Put error for UI
            
        finally:
            # --- FIX: Store final output for parser, then send end signal ---
            shared_output_list.append(full_output) 
            queue_.put(None) 
            # --- END FIX --- 
            

    def _check_for_updates(self):
        """
        Opens the update window and starts Phase 1 (Check).
        """
        script_path = os.path.join(self.base_dir, "..", "update.sh")
        
        if not os.path.exists(script_path):
            messagebox.showerror("Error", f"Update script not found at:\n{script_path}", parent=self.root)
            return

        # 1. Create the Log Window
        status_popup = tk.Toplevel(self.root)
        status_popup.title("System Update")
        status_popup.geometry("650x450")
        status_popup.transient(self.root)
        status_popup.grab_set()
        
        # 2. Text Area for Logging
        text_area = scrolledtext.ScrolledText(status_popup, wrap=tk.WORD, height=20, width=80)
        text_area.pack(padx=10, pady=10, fill="both", expand=True)
        
        text_area.tag_config("info", foreground="black")
        text_area.tag_config("success", foreground="green")
        text_area.tag_config("warning", foreground="#FF8C00") 
        text_area.tag_config("error", foreground="red")
        
        text_area.insert(tk.END, "Initializing update check...\n", "info")
        text_area.config(state="disabled")

        # 3. Button Frame
        btn_frame = ttk.Frame(status_popup, padding=(0, 0, 0, 10))
        btn_frame.pack(fill="x")
        
        # Define Buttons (Pack order: Right to Left)
        
        # A. Close (Window only)
        close_btn = ttk.Button(btn_frame, text="Close", state="disabled", command=status_popup.destroy)
        close_btn.pack(side="right", padx=5)
        
        # B. Close App (Shutdown app for restart) - Initially Disabled
        # Action: Destroy popup AND call the main UI closing sequence
        close_app_btn = ttk.Button(btn_frame, text="Close App (Restart)", state="disabled", 
                                   command=lambda: [status_popup.destroy(), self._on_closing_ui()])
        close_app_btn.pack(side="right", padx=5)
        
        # C. Install Updates - Initially Disabled
        install_btn = ttk.Button(btn_frame, text="Install Updates", state="disabled")
        install_btn.pack(side="right", padx=5)

        # 4. Start Phase 1: The Check
        threading.Thread(
            target=self._run_update_check_phase,
            args=(text_area, install_btn, close_btn, close_app_btn, script_path, status_popup),
            daemon=True
        ).start()

    def _safe_log_to_update_window(self, text_widget, message, tag="info"):
        """Helper to write to the scrolled text widget from a background thread."""
        def _update():
            if not text_widget.winfo_exists(): return
            text_widget.config(state="normal")
            text_widget.insert(tk.END, message + "\n", tag)
            text_widget.see(tk.END)
            text_widget.config(state="disabled")
        self.root.after(0, _update)

    def _run_update_check_phase(self, text_widget, install_btn, close_btn, close_app_btn, script_path, popup):
        """
        Phase 1: Runs git fetch/status to see if updates are needed.
        """
        self._safe_log_to_update_window(text_widget, "--- PHASE 1: CHECKING FOR UPDATES ---", "info")
        
        project_dir = os.path.dirname(self.base_dir)
        
        try:
            # Step A: Git Fetch
            self._safe_log_to_update_window(text_widget, "> git fetch origin", "info")
            subprocess.run(
                ['git', 'fetch', 'origin'], 
                cwd=project_dir, check=True, 
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            
            # Step B: Check Status
            self._safe_log_to_update_window(text_widget, "> git status -uno", "info")
            result = subprocess.run(
                ['git', 'status', '-uno'], 
                cwd=project_dir, check=True, 
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            
            output = result.stdout
            self._safe_log_to_update_window(text_widget, output, "info")
            
            # Step C: Analyze Result
            if "Your branch is behind" in output:
                self._safe_log_to_update_window(text_widget, "\n[!] UPDATE AVAILABLE", "success")
                self._safe_log_to_update_window(text_widget, "Click 'Install Updates' to proceed.", "info")
                
                # Enable Install Button via main thread
                def _enable_install():
                    if install_btn.winfo_exists():
                        install_btn.config(state="normal", 
                            command=lambda: self._start_install_phase(text_widget, install_btn, close_btn, close_app_btn, script_path))
                    if close_btn.winfo_exists():
                        close_btn.config(state="normal")
                self.root.after(0, _enable_install)
                
            elif "Your branch is up to date" in output:
                self._safe_log_to_update_window(text_widget, "\n[OK] System is up to date.", "success")
                self.root.after(0, lambda: close_btn.config(state="normal"))
                
            else:
                self._safe_log_to_update_window(text_widget, "\n[?] Status Unclear. Please check logs.", "warning")
                self.root.after(0, lambda: close_btn.config(state="normal"))

        except Exception as e:
            self._safe_log_to_update_window(text_widget, f"\n[ERROR] Check failed: {e}", "error")
            self.root.after(0, lambda: close_btn.config(state="normal"))

    def _start_install_phase(self, text_widget, install_btn, close_btn, close_app_btn, script_path):
        """Triggered by the Install button. Disables buttons and starts Phase 2."""
        install_btn.config(state="disabled")
        close_btn.config(state="disabled")
        # Close App remains disabled during install
        
        threading.Thread(
            target=self._run_update_install_phase,
            args=(text_widget, close_btn, close_app_btn, script_path),
            daemon=True
        ).start()

    def _run_update_install_phase(self, text_widget, close_btn, close_app_btn, script_path):
        """
        Phase 2: Runs the actual update.sh script and streams output.
        Enables 'Close App' button only on success.
        """
        self._safe_log_to_update_window(text_widget, "\n--- PHASE 2: INSTALLING UPDATES ---", "info")
        
        try:
            process = subprocess.Popen(
                ['sh', script_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, 
                text=True,
                encoding='utf-8',
                bufsize=1,
                start_new_session=True
            )
            
            for line in iter(process.stdout.readline, ''):
                self._safe_log_to_update_window(text_widget, line.strip(), "info")
                
            process.stdout.close()
            return_code = process.wait()
            
            if return_code == 0:
                self._safe_log_to_update_window(text_widget, "\n[SUCCESS] Update complete.", "success")
                self._safe_log_to_update_window(text_widget, "Click 'Close App (Restart)' to finish.", "success")
                
                # Enable the Close App button on success
                self.root.after(0, lambda: close_app_btn.config(state="normal"))
            else:
                self._safe_log_to_update_window(text_widget, f"\n[ERROR] Update script failed with code {return_code}", "error")

        except Exception as e:
             self._safe_log_to_update_window(text_widget, f"\n[ERROR] Failed to run update script: {e}", "error")
             
        finally:
            # Always re-enable the standard close button so user isn't stuck
            self.root.after(0, lambda: close_btn.config(state="normal"))
                 
    def get_git_commit_hash(self):
        """Attempts to get the short git commit hash of the current build."""
        try:
            # Assumes git is installed and this is running from within the repo
            # --git-dir specifies the .git folder location relative to the script
            # --work-tree specifies the root of the working copy
            
            # --- MODIFICATION: Use self.base_dir to find the .git folder ---
            # self.base_dir is src, so ../.git points to the repo root
            git_dir = os.path.join(self.base_dir, "..", ".git")
            work_tree = os.path.join(self.base_dir, "..")
            
            if not os.path.isdir(git_dir):
                # Fallback: Check if .git is in the current dir (e.g., running from root)
                git_dir = os.path.join(self.base_dir, ".git")
                work_tree = self.base_dir
                if not os.path.isdir(git_dir):
                    print("Debug: .git directory not found.")
                    return None

            result = subprocess.run(
                ['git', f'--git-dir={git_dir}', f'--work-tree={work_tree}', 'rev-parse', '--short', 'HEAD'],
                capture_output=True, text=True, check=True, encoding='utf-8'
            )
            return result.stdout.strip()
        except FileNotFoundError:
            print("Git executable not found.")
            return None
        except subprocess.CalledProcessError as e:
            print(f"Git rev-parse failed: {e.stderr}")
            return None
        except Exception as e:
            print(f"Error getting git commit: {e}")
            return None

    def _setup_menu_commands(self):
        """Builds the Settings menu, assigning commands to popup methods."""
        
        # --- 1. Configuration ---
        self.settings_menu.add_command(label="Configuration", font=self.menu_heading_font, state="disabled")
        
        self.settings_menu.add_command(label="Keg Settings", command=self._open_keg_settings_popup)
        self.settings_menu.add_command(label="Beverage Library", command=self._open_beverage_library_popup)
        self.settings_menu.add_command(label="Notification Settings", command=self._open_message_settings_popup)
        self.settings_menu.add_command(label="Flow Sensor Calibration", command=self._open_flow_calibration_popup)
        self.settings_menu.add_command(label="System Settings", command=self._open_system_settings_popup)
        
        self.settings_menu.add_separator()
        
        # --- 2. Utilities ---
        self.settings_menu.add_command(label="Utilities", font=self.menu_heading_font, state="disabled")
        self.settings_menu.add_command(label="KegLevel Workflow", command=self._open_workflow_popup)
        self.settings_menu.add_command(label="Temperature Log", command=self._open_temperature_log_popup)
        
        self.settings_menu.add_separator()
        
        # --- 3. Maintenance (NEW SECTION) ---
        self.settings_menu.add_command(label="Maintenance", font=self.menu_heading_font, state="disabled")
        self.settings_menu.add_command(label="Check for Updates", command=self._check_for_updates)
        self.settings_menu.add_command(label="Reset to Defaults", command=self._open_reset_to_defaults_popup)
        
        self.settings_menu.add_separator()
        
        # --- 4. App Info (RENAMED) ---
        self.settings_menu.add_command(label="App Info", font=self.menu_heading_font, state="disabled")
        self.settings_menu.add_command(label="Wiring Diagram", command=self._open_wiring_diagram_popup)
        
        # NEW: Help Placeholder
        self.settings_menu.add_command(label="Help", command=self._open_help_popup)
        
        self.settings_menu.add_command(label="Support this App", command=lambda: self._open_support_popup(is_launch=False))
        self.settings_menu.add_command(label="About...", command=self._open_about_popup)

    def _open_about_popup(self):
        try:
            APP_REVISION = self.__class__.__bases__[0].APP_REVISION
        except:
             APP_REVISION = "Unknown"
             
        popup = tk.Toplevel(self.root)
        popup.title("About..."); popup.geometry("750x520"); popup.resizable(False, False); popup.transient(self.root); popup.grab_set()

        frame = ttk.Frame(popup, padding="10"); frame.pack(expand=True, fill="both")

        copyright_text = (
            "KegLevel Monitor(c) and KegLevel Workflow(c) names, texts, UI/UX "
            "(User Interface/User Experience or Graphical User Interface) and program code are copyrighted. "
            "This material and all components of this program are protected by "
            "copyright law. Unauthorized use, duplication, or distribution is "
            "strictly prohibited. This application is in beta testing. To request beta test status send a "
            "request including your full name and email address to KegLevelMonitor@gmail.com."

            # "KegLevel Monitor(c) and KegLevel Workflow(c) names, texts, UI/UX "
            # "(User Interface/User Experience or Graphical User Interface) and program code are copyrighted. "
            # "This material and all components of this program are protected by "
            # "copyright law. Unauthorized use, duplication, or distribution is "
            # "strictly prohibited. For information contact the author/owner by email: KegLevelMonitor@gmail.com. "
            # "Inquiries must include your full name and your country of residence including the state/province/district. "
        )

        ttk.Label(frame, text="KegLevel Monitor", font=('TkDefaultFont', 14, 'bold')).pack(pady=(0, 10))
        ttk.Label(frame, text=copyright_text, wraplength=700, justify=tk.LEFT).pack(anchor='w', pady=(0, 10))
        
        # --- REFACTOR: Simplified version string (matches FermVault) ---
        version_display = self.app_version_string if self.app_version_string else 'Unknown'
        commit_hash = self.get_git_commit_hash()
        
        if commit_hash:
            version_text = f"Version: {version_display} (Commit: {commit_hash})"
        else:
            version_text = f"Version: {version_display}"
        # --- END REFACTOR ---
                       
        ttk.Label(frame, text=version_text, font=('TkDefaultFont', 10, 'italic')).pack(anchor='w', pady=(5, 5))
        
        # --- REMOVED: License Key Status logic ---
        
        self._add_changelog_section(frame, popup) 
        
        # --- FIXED: Attribution Link display (text should be the clickable link) ---
        # The display needs to be clickable. In Tkinter, this means creating a clickable label.
        
        # Function to open the link in a browser (Tkinter friendly)
        def open_flaticon_link(event):
            try:
                import webbrowser
                webbrowser.open_new("https://www.flaticon.com/free-icons/update")
            except Exception as e:
                messagebox.showerror("Link Error", f"Could not open link: {e}", parent=popup)

        link_label = ttk.Label(
            popup, 
            text="Beer Keg and Update icons created by Pixel Perfect - Flaticon", 
            foreground="blue", 
            cursor="hand2", 
            font=('TkDefaultFont', 8, 'italic', 'underline'), 
            wraplength=700, 
            justify=tk.LEFT
        )
        # Pack the link label first to ensure it's at the absolute bottom
        link_label.pack(fill="x", side="bottom", pady=(0, 5), padx=10) 
        link_label.bind("<Button-1>", open_flaticon_link)
        # --- END FIXED: Attribution Link ---
        
        buttons_frame = ttk.Frame(popup, padding=(10, 5)); 
        # Pack buttons just above the attribution frame
        buttons_frame.pack(fill="x", side="bottom") 
        
        # --- REFACTOR: "Close" button packed to the right ---
        ttk.Button(buttons_frame, text="Close", command=popup.destroy, width=10).pack(side="right", pady=5)
        
        # --- REFACTOR: "Support" button packed to the left ---
        ttk.Button(buttons_frame, text="Support this App", command=lambda: self._open_support_popup(is_launch=False), width=15).pack(side="left", padx=(0, 5), pady=5)
        # --- END REFACTOR ---
        
        popup.update_idletasks()
        popup.geometry("750x520")

    def _add_changelog_section(self, parent_frame, popup_window):
        """Adds a scrollable changelog text area to the About popup."""
        
        ttk.Label(parent_frame, text="Change Log", font=('TkDefaultFont', 10, 'bold')).pack(anchor='w', pady=(5, 5))

        text_frame = ttk.Frame(parent_frame); text_frame.pack(fill="both", expand=True)
        text_frame.grid_columnconfigure(0, weight=1); text_frame.grid_rowconfigure(0, weight=1)

        changelog_text = tk.Text(text_frame, height=12, wrap='word', state='disabled', relief='sunken', borderwidth=1)
        changelog_text.grid(row=0, column=0, sticky="nsew")

        v_scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=changelog_text.yview)
        v_scrollbar.grid(row=0, column=1, sticky="ns")
        changelog_text.config(yscrollcommand=v_scrollbar.set)

        # --- REFACTOR: Look in the 'assets' subdirectory ---
        changelog_path = os.path.join(self.base_dir, "assets", "changelog.txt")
        # --- END REFACTOR ---
        log_content = "Changelog file not found."
        
        try:
            with open(changelog_path, 'r', encoding='utf-8') as f:
                log_content = f.read()
        except FileNotFoundError:
            pass
        except Exception as e:
            log_content = f"Error loading changelog: {e}"

        changelog_text.config(state='normal')
        changelog_text.insert(tk.END, log_content)
        changelog_text.config(state='disabled')
        
    def _open_beverage_library_popup(self):
        popup = tk.Toplevel(self.root)
        popup.title("Beverage Library"); popup.geometry("800x480"); popup.transient(self.root); popup.grab_set()
        main_frame = ttk.Frame(popup, padding="10"); main_frame.pack(expand=True, fill="both")
        
        canvas = tk.Canvas(main_frame, borderwidth=0)
        v_scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scroll_frame = ttk.Frame(canvas)
        v_scrollbar.pack(side="right", fill="y"); canvas.pack(side="left", fill="both", expand=True)
        canvas.configure(yscrollcommand=v_scrollbar.set)
        canvas_window = canvas.create_window((0, 0), window=scroll_frame, anchor="nw", width=800) 

        def on_frame_configure(event): canvas.configure(scrollregion=canvas.bbox("all"))
        scroll_frame.bind("<Configure>", on_frame_configure)
        def on_canvas_resize(event): canvas.itemconfig(canvas_window, width=event.width)
        canvas.bind('<Configure>', on_canvas_resize)

        self.beverage_popup_vars = []
        beverage_list = self.settings_manager.get_beverage_library().get('beverages', [])
        scroll_frame.grid_columnconfigure(0, weight=1); scroll_frame.grid_columnconfigure(1, weight=0); scroll_frame.grid_columnconfigure(2, weight=0)

        header_frame = ttk.Frame(scroll_frame); header_frame.grid(row=0, column=0, columnspan=2, sticky='ew', padx=5, pady=5)
        header_frame.grid_columnconfigure(0, weight=1); header_frame.grid_columnconfigure(1, weight=0); header_frame.grid_columnconfigure(2, weight=0)
        ttk.Label(header_frame, text="Beverage Name", font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=0, padx=5, sticky='w')
        ttk.Label(header_frame, text="Actions", font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=1, columnspan=2, sticky='w', padx=(20, 5))

        BG_EVEN = '#FFFFFF'; BG_ODD = '#F5F5F5' 

        for i in range(len(beverage_list)):
            beverage = beverage_list[i]; row = i + 1; bg_color = BG_ODD if i % 2 else BG_EVEN
            row_frame = tk.Frame(scroll_frame, bg=bg_color, relief='flat', bd=0); row_frame.grid(row=row, column=0, columnspan=2, sticky='ew', pady=(1, 0))
            row_frame.grid_columnconfigure(0, weight=1); row_frame.grid_columnconfigure(1, weight=0); row_frame.grid_columnconfigure(2, weight=0)
            
            name_label_text = tk.StringVar(value=beverage.get('name', ''))
            ttk.Label(row_frame, textvariable=name_label_text, anchor='w', background=bg_color, padding=(5, 5)).grid(row=0, column=0, sticky='w')
            self.beverage_popup_vars.append(name_label_text)
            
            ttk.Button(row_frame, text="Edit", width=8, 
                       command=lambda b=beverage, p=popup: self._open_beverage_edit_popup(b, p)).grid(row=0, column=1, padx=(10, 5), pady=2, sticky='e')

            ttk.Button(row_frame, text="Delete", width=8, style="TButton", 
                       command=lambda b_id=beverage.get('id'), b_name=beverage.get('name'), 
                       p=popup: self._delete_beverage(b_id, b_name, p)).grid(row=0, column=2, padx=(0, 5), pady=2, sticky='e')

        footer_frame = ttk.Frame(popup, padding="10"); 
        footer_frame.pack(fill="x", side="bottom", pady=(10, 0))
        
        ttk.Button(footer_frame, text="Add New Beverage", 
                   command=lambda p=popup: self._open_beverage_edit_popup(None, p)).pack(side="left", padx=5)

        ttk.Button(footer_frame, text="Close", 
                   command=lambda p=popup: self._close_and_sort_beverage_library_popup(p)).pack(side="right", padx=5)

        # NEW Help Button
        ttk.Button(footer_frame, text="Help", width=8,
                   command=lambda: self._open_help_popup("beverage_library")).pack(side="right", padx=5)

        center_import_frame = ttk.Frame(footer_frame)
        center_import_frame.pack(expand=True, fill="x", padx=10) 

        available_libraries = self.settings_manager.get_available_addon_libraries()
        library_options = ["Select Library"] + available_libraries
        
        self.bjcp_import_var = tk.StringVar(value=library_options[0]) 
        
        import_dropdown = ttk.Combobox(center_import_frame, textvariable=self.bjcp_import_var, 
                                       values=library_options, state="readonly", width=20)
        import_dropdown.pack(side="left", padx=(0, 5), anchor="center")
        
        ttk.Button(center_import_frame, text="Import", width=8, 
                   command=lambda p=popup: self._validate_and_open_dialog('import', p, self.bjcp_import_var.get())).pack(side="left", padx=(0, 10), anchor="center")

        ttk.Button(center_import_frame, text="Delete", width=8, 
                   command=lambda p=popup: self._validate_and_open_dialog('delete', p, self.bjcp_import_var.get())).pack(side="left", padx=(0, 5), anchor="center")
        
        scroll_frame.update_idletasks()
        
    def _close_and_sort_beverage_library_popup(self, popup_window):
        beverage_library = self.settings_manager.get_beverage_library()
        beverage_list = beverage_library.get('beverages', [])
        
        try:
            sorted_list = sorted(beverage_list, key=lambda b: b.get('name', '').lower())
        except Exception as e:
            messagebox.showerror("Sort Error", f"An error occurred during automatic sorting of the library. {e}", parent=popup_window)
            popup_window.destroy(); return

        self.settings_manager.save_beverage_library(sorted_list)
        print("UIManager: Beverage library automatically sorted and saved upon close.")
        
        self._populate_beverage_dropdowns()
        self._refresh_beverage_metadata()
        
        if hasattr(self, 'workflow_app') and self.workflow_app and self.workflow_app.popup.winfo_exists():
             self.workflow_app._refresh_all_columns()

        popup_window.destroy()

    def _open_beverage_edit_popup(self, beverage_data=None, parent_popup=None):
        is_new = beverage_data is None; popup = tk.Toplevel(self.root)
        beverage_name = beverage_data.get('name', 'Beverage') if beverage_data else 'Beverage'
        popup.title("Add New Beverage" if is_new else f"Edit {beverage_name}"); popup.geometry("600x450")
        popup.transient(self.root); popup.grab_set()

        form_frame = ttk.Frame(popup, padding="15"); form_frame.pack(expand=True, fill="both")
        
        default_data = {
            'id': str(uuid.uuid4()), 'name': '', 'bjcp': '', 'abv': '', 'ibu': None, 'description': ''
        }
        data = beverage_data if beverage_data else default_data

        temp_vars = {
            'id': tk.StringVar(value=data.get('id')),
            'name': tk.StringVar(value=data.get('name')),
            'bjcp': tk.StringVar(value=data.get('bjcp')), 
            'abv': tk.StringVar(value=data.get('abv')),
            'ibu': tk.StringVar(value=str(data.get('ibu', '')) if data.get('ibu') is not None else ''),
            'description': tk.StringVar(value=data.get('description'))
        }

        row_idx = tk.IntVar(value=0)

        def add_field(parent, label_text, var, width, is_text=False, max_len=None, row=None):
            ttk.Label(parent, text=label_text, width=15, anchor="w").grid(row=row, column=0, padx=5, pady=5 if not is_text else (10,0), sticky='w')
            if is_text:
                text_widget = tk.Text(parent, height=5, width=width, wrap=tk.WORD)
                text_widget.insert(tk.END, var.get())
                text_widget.grid(row=row, column=1, sticky='nsew', padx=5, pady=5)
                return text_widget 
            else:
                entry = ttk.Entry(parent, textvariable=var, width=width)
                entry.grid(row=row, column=1, sticky='ew', padx=5, pady=5)
            if max_len and not is_text:
                ttk.Label(parent, text=f"({max_len} chars)", font=('TkDefaultFont', 8, 'italic')).grid(row=row, column=2, sticky='w', padx=2)
            return None 

        form_frame.grid_columnconfigure(0, weight=0); form_frame.grid_columnconfigure(1, weight=1); form_frame.grid_columnconfigure(2, weight=0)
        
        add_field(form_frame, "Beverage Name:", temp_vars['name'], 25, row=row_idx.get(), max_len=35); row_idx.set(row_idx.get() + 1)
        add_field(form_frame, "BJCP/Style Name:", temp_vars['bjcp'], 25, row=row_idx.get()); row_idx.set(row_idx.get() + 1)
        add_field(form_frame, "ABV (e.g. 5.5):", temp_vars['abv'], 10, row=row_idx.get()); row_idx.set(row_idx.get() + 1)
        add_field(form_frame, "IBU (0-100):", temp_vars['ibu'], 10, row=row_idx.get()); row_idx.set(row_idx.get() + 1)
        
        description_row = row_idx.get()
        description_text_widget = add_field(form_frame, "Description:", temp_vars['description'], 40, is_text=True, max_len=255, row=description_row)
        form_frame.grid_rowconfigure(description_row, weight=1); row_idx.set(row_idx.get() + 1)

        # Footer Buttons
        btns_frame = ttk.Frame(popup, padding="10"); btns_frame.pack(fill="x", side="bottom")
        
        ttk.Button(btns_frame, text="Save", command=lambda p=popup: self._save_beverage(temp_vars, description_text_widget, is_new, p, parent_popup)).pack(side="right", padx=5)
        ttk.Button(btns_frame, text="Cancel", command=popup.destroy).pack(side="right", padx=5)
        
        # NEW Help Button
        ttk.Button(btns_frame, text="Help", width=8, 
                   command=lambda: self._open_help_popup("beverage_library")).pack(side="right", padx=5)

        popup.update_idletasks()
        
    def _save_beverage(self, temp_vars, description_text_widget, is_new, popup_window, parent_popup):
        try:
            name = temp_vars['name'].get().strip(); ibu_str = temp_vars['ibu'].get().strip(); abv = temp_vars['abv'].get().strip()
            bjcp_style = temp_vars['bjcp'].get().strip(); description = description_text_widget.get("1.0", tk.END).strip()
            
            if not name: messagebox.showerror("Input Error", "Beverage Name cannot be empty.", parent=popup_window); return
            if len(name) > 35: messagebox.showerror("Input Error", "Beverage Name is limited to 35 characters.", parent=popup_window); return
            if len(bjcp_style) > 35: messagebox.showerror("Input Error", "BJCP/Style Name is limited to 35 characters.", parent=popup_window); return
            if not (0 <= len(abv) <= 5): messagebox.showerror("Input Error", "ABV is limited to 5 characters (e.g., 5.5).", parent=popup_window); return
            
            ibu = None
            if ibu_str:
                try:
                    ibu = int(ibu_str)
                    if not (0 <= ibu <= 100): raise ValueError
                except ValueError:
                    messagebox.showerror("Input Error", "IBU must be blank or a whole number between 0 and 100.", parent=popup_window); return
            
            new_data = {
                "id": temp_vars['id'].get(), "name": name, "bjcp": bjcp_style, 
                "abv": abv, "ibu": ibu, "description": description 
            }
            beverage_list = self.settings_manager.get_beverage_library().get('beverages', [])
            
            if is_new: beverage_list.append(new_data)
            else:
                found = False
                for i, b in enumerate(beverage_list):
                    if b.get('id') == new_data['id']: 
                        if b.get('source_library'):
                            new_data['source_library'] = b['source_library']
                        beverage_list[i] = new_data; 
                        found = True; 
                        break
                if not found: messagebox.showerror("Save Error", "Could could not find the original beverage to update.", parent=popup_window); return

            sorted_list = sorted(beverage_list, key=lambda b: b.get('name', '').lower())
            self.settings_manager.save_beverage_library(sorted_list)
            
            self._populate_beverage_dropdowns()
            self._refresh_beverage_metadata()
            
            if hasattr(self, 'workflow_app') and self.workflow_app and self.workflow_app.popup.winfo_exists(): self.workflow_app._refresh_all_columns()
                 
            popup_window.destroy()
            if parent_popup and parent_popup.winfo_exists():
                 parent_popup.destroy() 
                 self._open_beverage_library_popup()
            
            print(f"UIManager: Beverage '{name}' saved and sorted successfully.")

        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred while saving the beverage: {e}", parent=popup_window)
            
    def _delete_beverage(self, beverage_id, beverage_name, parent_popup):
        if not messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete the beverage '{beverage_name}'? This cannot be undone.", parent=parent_popup): return
            
        beverage_list = self.settings_manager.get_beverage_library().get('beverages', [])
        new_list = [b for b in beverage_list if b.get('id') != beverage_id]
        assignments = self.settings_manager.get_sensor_beverage_assignments()
        
        first_beverage_id = new_list[0]['id'] if new_list else self.settings_manager._get_default_beverage_library().get('beverages')[0]['id']
        
        needs_assignment_update = False
        for i in range(len(assignments)):
            if assignments[i] == beverage_id:
                assignments[i] = first_beverage_id
                needs_assignment_update = True
        
        if needs_assignment_update:
            for i in range(len(assignments)): self.settings_manager.save_sensor_beverage_assignment(i, assignments[i])
            print("UIManager: Re-assigned taps after deleting a beverage.")
            
        sorted_list = sorted(new_list, key=lambda b: b.get('name', '').lower())
        self.settings_manager.save_beverage_library(sorted_list)

        self._populate_beverage_dropdowns()
        self._refresh_beverage_metadata()

        if hasattr(self, 'workflow_app') and self.workflow_app and self.workflow_app.popup.winfo_exists(): self.workflow_app._refresh_all_columns()
             
        parent_popup.destroy() 
        if self.settings_manager.get_beverage_library().get('beverages'): self._open_beverage_library_popup()
        else: messagebox.showinfo("Library Empty", "The Beverage Library is now empty.", parent=self.root)

    
    # --- NEW: Import Dialog Logic (Unchanged) ---
    def _open_bjcp_import_dialog(self, parent_popup, addon_name):
        addon_list = self.settings_manager.load_addon_library(addon_name)
        if addon_list is None:
            messagebox.showerror("Import Error", f"Could not load the {addon_name} file for pre-check.", parent=parent_popup)
            return

        current_beverages = self.settings_manager.get_beverage_library().get('beverages', [])
        current_ids = {b['id'] for b in current_beverages if 'id' in b}
        entries_to_import = [b for b in addon_list if b.get('id') not in current_ids]
        import_count = len(entries_to_import)

        popup = tk.Toplevel(self.root); popup.title(f"Confirm Import: {addon_name}"); popup.geometry("450x200"); popup.transient(self.root); popup.grab_set()
        
        frame = ttk.Frame(popup, padding="15"); frame.pack(expand=True, fill="both")
        
        message_text = (
            "The library contains {import_count} entries. Once imported, the library entries can be "
            "individually edited or deleted. The library entries may be deleted all at once "
            "with the Delete function, but any library entries that have been edited will not "
            "be deleted."
        ).format(import_count=import_count) 
        ttk.Label(frame, text=message_text, wraplength=400, justify=tk.LEFT).pack(pady=(0, 20))
        
        buttons_frame = ttk.Frame(popup, padding="10"); buttons_frame.pack(fill="x", side="bottom")
        
        ttk.Button(buttons_frame, text="Cancel", command=popup.destroy).pack(side="right", padx=5)
        ttk.Button(buttons_frame, text="Continue", 
                   command=lambda: self._execute_bjcp_import(addon_name, popup, parent_popup)).pack(side="right")

    def _execute_bjcp_import(self, addon_name, dialog_popup, library_popup):
        success, message, new_count = self.settings_manager.import_beverages_from_addon(addon_name)
        
        dialog_popup.destroy()
        library_popup.destroy()

        if success:
            messagebox.showinfo("Import Successful", f"{message}", parent=self.root)
            self._open_beverage_library_popup()
            self._populate_beverage_dropdowns()
            self._refresh_beverage_metadata()
            if hasattr(self, 'workflow_app') and self.workflow_app and self.workflow_app.popup.winfo_exists():
                 self.workflow_app._refresh_all_columns()
        else:
            messagebox.showerror("Import Failed", message, parent=self.root)

    # --- NEW: Delete Dialog Logic (Unchanged) ---
    def _open_bjcp_delete_dialog(self, parent_popup, addon_name):
        popup = tk.Toplevel(self.root); popup.title(f"Confirm Delete: {addon_name}"); popup.geometry("450x200"); popup.transient(self.root); popup.grab_set()
        
        frame = ttk.Frame(popup, padding="15"); frame.pack(expand=True, fill="both")
        
        message_text = (
            "This action attempts to remove all original entries from the imported library. Any "
            "imported library entries that have been edited will not be deleted. Any taps assigned "
            "to these entries will be reassigned to the first beverage in the list of beverages."
        )
        ttk.Label(frame, text=message_text, wraplength=400, justify=tk.LEFT).pack(pady=(0, 20))
        
        buttons_frame = ttk.Frame(popup, padding="10"); buttons_frame.pack(fill="x", side="bottom")
        
        ttk.Button(buttons_frame, text="Cancel", command=popup.destroy).pack(side="right", padx=5)
        ttk.Button(buttons_frame, text="Continue", 
                   command=lambda: self._execute_bjcp_delete(addon_name, popup, parent_popup)).pack(side="right")

    def _execute_bjcp_delete(self, addon_name, dialog_popup, library_popup):
        success, message, total_original_count, deleted_count = self.settings_manager.delete_beverages_from_addon(addon_name)
        
        dialog_popup.destroy()
        library_popup.destroy()
        
        if success:
            messagebox.showinfo("Delete Successful", 
                                f"Successfully deleted {deleted_count} of {total_original_count} original entries from {addon_name}. Taps were reassigned.", 
                                parent=self.root)
            self._open_beverage_library_popup()
            self._populate_beverage_dropdowns()
            self._refresh_beverage_metadata()
            if hasattr(self, 'workflow_app') and self.workflow_app and self.workflow_app.popup.winfo_exists():
                 self.workflow_app._refresh_all_columns()
        else:
            messagebox.showerror("Import Failed", message, parent=self.root)

    def _validate_and_open_dialog(self, action, parent_popup, selected_library_name):
        """Checks if a valid library is selected before opening the import/delete dialog."""
        if selected_library_name == "Select Library" or not selected_library_name:
            messagebox.showerror("Selection Error", "Please select a valid library to proceed.", parent=parent_popup)
            return

        if action == 'import':
            self._open_bjcp_import_dialog(parent_popup, selected_library_name)
        elif action == 'delete':
            self._open_bjcp_delete_dialog(parent_popup, selected_library_name)

    # --- Keg Settings Helper Methods (REPLACED/MODIFIED) ---
    
    # --- FIX: Added 'row' parameter to the internal helper function signature ---
    def _add_link_field(self, parent, label_text, var, unit, row, readonly=False):
        """Helper to create and place linked fields for the edit popup."""
        ttk.Label(parent, text=label_text, width=25, anchor="w").grid(row=row, column=0, padx=5, pady=5, sticky='w')
        entry = ttk.Entry(parent, textvariable=var, width=15, state=('readonly' if readonly else 'normal'))
        entry.grid(row=row, column=1, sticky='ew', padx=5, pady=5)
        if unit: ttk.Label(parent, text=unit).grid(row=row, column=2, sticky='w', padx=2)
        return entry

    def _keg_edit_link_weight_to_volume(self, temp_vars, source_var):
        """
        Performs the linked calculation between weight and volume in the edit popup.
        
        FIX: The trace handler is ONLY attached to tare_weight_kg and total_weight_kg.
        Maximum Full Volume should NOT trigger this calculation.
        """
        
        # Determine current units for parsing inputs
        display_units = self.settings_manager.get_display_units()
        weight_conversion = 1.0 if display_units == "metric" else KG_TO_LB
        volume_conversion = 1.0 if display_units == "metric" else LITERS_TO_GALLONS

        # Temporarily remove trace to prevent infinite loop
        # ONLY remove traces for the variables that trigger the calculation.
        for var_name in ['tare_weight_kg', 'total_weight_kg']:
            trace_id = getattr(temp_vars[var_name], '_trace_id', None)
            if trace_id: 
                 try: temp_vars[var_name].trace_remove("write", trace_id)
                 except tk.TclError: pass
        
        try:
            # Read the current displayed value from the entry widget
            # Note: The helper function binds FocusOut to update the underlying 'kg' variable, 
            # so we read the stored KG value here, which is more reliable than reading the entry widget text.
            empty_kg = float(temp_vars['tare_weight_kg'].get())
            total_kg = float(temp_vars['total_weight_kg'].get())
        except ValueError: 
            # If weight entries are invalid, show error in volume field
            temp_vars['starting_volume_display'].set("--.--")
            self._re_add_keg_edit_traces(temp_vars); return
        
        if total_kg >= empty_kg and empty_kg >= 0 and total_kg >= 0:
             # Calculate volume in liters (stored unit)
             new_vol_liters = self.settings_manager._calculate_volume_from_weight(total_kg, empty_kg)
             
             # Convert liters to displayed volume unit for setting the StringVar
             new_vol_display = new_vol_liters * volume_conversion
             temp_vars['starting_volume_display'].set(f"{new_vol_display:.2f}")
        else:
             temp_vars['starting_volume_display'].set("--.--")

        self._re_add_keg_edit_traces(temp_vars)

    def _re_add_keg_edit_traces(self, temp_vars):
        """
        Re-adds the traces after a calculated change in the edit popup.
        
        FIX: ONLY adds traces to the weight fields.
        """
        
        # We trace the underlying KG variable's write event, but the handler reads the actual Entry text
        def trace_handler(var_name):
            return lambda n, i, m, r=temp_vars: self._keg_edit_link_weight_to_volume(r, var_name)
            
        # ONLY trace the weight-related variables
        temp_vars['tare_weight_kg']._trace_id = temp_vars['tare_weight_kg'].trace_add("write", trace_handler('tare_weight_kg'))
        temp_vars['total_weight_kg']._trace_id = temp_vars['total_weight_kg'].trace_add("write", trace_handler('total_weight_kg'))

    # --- Keg Settings Popup Logic (RESTRUCTURED TO MIRROR BEVERAGE LAYOUT) ---
    
    def _open_keg_settings_popup(self):
        # UI mirrors the Beverage Library for consistent behavior
        popup = tk.Toplevel(self.root)
        popup.title("Keg Settings"); popup.geometry("800x480"); popup.transient(self.root); popup.grab_set() # TITLE RENAMED
        main_frame = ttk.Frame(popup, padding="10"); main_frame.pack(expand=True, fill="both")
        
        canvas = tk.Canvas(main_frame, borderwidth=0)
        v_scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scroll_frame = ttk.Frame(canvas)
        v_scrollbar.pack(side="right", fill="y"); canvas.pack(side="left", fill="both", expand=True)
        canvas.configure(yscrollcommand=v_scrollbar.set)
        canvas_window = canvas.create_window((0, 0), window=scroll_frame, anchor="nw", width=800) 

        def on_frame_configure(event): canvas.configure(scrollregion=canvas.bbox("all"))
        scroll_frame.bind("<Configure>", on_frame_configure)
        def on_canvas_resize(event): canvas.itemconfig(canvas_window, width=event.width)
        canvas.bind('<Configure>', on_canvas_resize)

        self.keg_settings_popup_vars = []
        
        # Auto-sort the list upon opening the popup
        keg_list_unsorted = self.settings_manager.get_keg_definitions()
        keg_list = sorted(keg_list_unsorted, key=lambda k: k.get('title', '').lower())


        # Grid column configuration for scroll_frame: Col 0 (Title) expands, Col 1 (Edit), Col 2 (Delete) fixed
        # This matches the Beverage Library's layout setup.
        scroll_frame.grid_columnconfigure(0, weight=1); 
        scroll_frame.grid_columnconfigure(1, weight=0); 
        scroll_frame.grid_columnconfigure(2, weight=0); 

        # --- Header Row (Simplified to match Beverage Library) ---
        header_frame = ttk.Frame(scroll_frame); 
        # Span across all three main columns for alignment
        header_frame.grid(row=0, column=0, columnspan=3, sticky='ew', padx=5, pady=5)
        
        # Configure internal header grid: Col 0 expands (for Title), Col 1 & 2 for actions
        header_frame.grid_columnconfigure(0, weight=1); 
        header_frame.grid_columnconfigure(1, weight=0);
        header_frame.grid_columnconfigure(2, weight=0);
        
        # --- Headers ---
        ttk.Label(header_frame, text="Keg Title", font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=0, padx=5, sticky='w')
        # Combine Edit/Delete header into 'Actions' spanning two button columns
        ttk.Label(header_frame, text="Actions", font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=1, columnspan=2, sticky='w', padx=(20, 5))


        BG_EVEN = '#FFFFFF'; BG_ODD = '#F5F5F5' 

        # --- Keg List Rows (Simplified to match Beverage Library) ---
        for i in range(len(keg_list)):
            keg = keg_list[i]; row = i + 1; bg_color = BG_ODD if i % 2 else BG_EVEN
            
            # Row Frame: Spans 3 columns of the scroll_frame
            row_frame = tk.Frame(scroll_frame, bg=bg_color, relief='flat', bd=0); 
            row_frame.grid(row=row, column=0, columnspan=3, sticky='ew', pady=(1, 0))
            
            # Configure row_frame internal grid: Col 0 for Title (Expands), Col 1 (Edit), Col 2 (Delete) fixed
            row_frame.grid_columnconfigure(0, weight=1) 
            row_frame.grid_columnconfigure(1, weight=0) 
            row_frame.grid_columnconfigure(2, weight=0) 
            
            # Col 0: Keg Title (WIDGET IS ALIGNED LEFT AND EXPANDS)
            title_label_text = tk.StringVar(value=keg.get('title', ''))
            
            # FIX: Add the label widget to display the title_label_text
            ttk.Label(row_frame, textvariable=title_label_text, anchor='w', background=bg_color, 
                      padding=(5, 5)).grid(row=0, column=0, sticky='ew', padx=5)
            
            self.keg_settings_popup_vars.append(title_label_text) # Keep track of the StringVar
            
            # Col 1: Edit Button
            ttk.Button(row_frame, text="Edit", width=8, 
                       command=lambda k=keg.copy(), p=popup: self._open_keg_edit_popup(k, p)).grid(row=0, column=1, padx=(10, 5), pady=2, sticky='e')

            # Col 2: Delete Button
            ttk.Button(row_frame, text="Delete", width=8, style="TButton", 
                       command=lambda k_id=keg.get('id'), k_name=keg.get('title'), 
                       p=popup: self._delete_keg_definition(k_id, k_name, p)).grid(row=0, column=2, padx=(0, 5), pady=2, sticky='e')

        footer_frame = ttk.Frame(popup, padding="10"); 
        footer_frame.pack(fill="x", side="bottom", pady=(10, 0))
        
        ttk.Button(footer_frame, text="Add New Keg", 
                   command=lambda p=popup: self._open_keg_edit_popup(None, p)).pack(side="left", padx=5)

        ttk.Button(footer_frame, text="Close", command=popup.destroy).pack(side="right", padx=5)
        # NEW HELP BUTTON
        ttk.Button(footer_frame, text="Help", width=8,
                   command=lambda: self._open_help_popup("keg_settings")).pack(side="right", padx=5)
        
        scroll_frame.update_idletasks()


    def _open_keg_edit_popup(self, keg_data=None, parent_popup=None):
        is_new = keg_data is None; popup = tk.Toplevel(self.root)
        keg_title = keg_data.get('title', 'New Keg') if keg_data else 'New Keg'
        
        # Geometry restored for a tighter fit after aesthetic cleanup
        popup.title("Add New Keg" if is_new else f"Edit {keg_title}"); popup.geometry("550x400"); popup.transient(self.root); popup.grab_set()

        form_frame = ttk.Frame(popup, padding="15"); form_frame.pack(expand=True, fill="both")
        
        # Determine current units
        display_units = self.settings_manager.get_display_units()
        weight_unit = "kg" if display_units == "metric" else "lb"
        volume_unit = "Liters" if display_units == "metric" else "Gallons"
        weight_conversion = 1.0 if display_units == "metric" else KG_TO_LB
        volume_conversion = 1.0 if display_units == "metric" else LITERS_TO_GALLONS
        entry_width = 10 # Standard width for all numeric fields
        
        # Use the first default keg profile to populate missing keys on existing kegs
        default_data = self.settings_manager._get_default_keg_definitions()[0] 
        data = keg_data if keg_data else default_data.copy()

        # Data from settings is ALWAYS in KG/LITERS
        max_vol_l = data.get('maximum_full_volume_liters', default_data['maximum_full_volume_liters'])
        start_vol_l = data.get('calculated_starting_volume_liters', 0.0)
        dispensed_l = data.get('current_dispensed_liters', 0.0)
        # Calculate Remaining Volume (Live Volume)
        remaining_l = max(0.0, start_vol_l - dispensed_l)
        
        empty_kg = data.get('tare_weight_kg', 0.0)
        total_kg = data.get('starting_total_weight_kg', 0.0)
        
        # Convert KG/Liters to display units
        max_vol_display = max_vol_l * volume_conversion
        start_vol_display = start_vol_l * volume_conversion
        # Current Remaining Volume in display units
        remaining_display = remaining_l * volume_conversion

        # New variable set for the editor. 
        temp_vars = {
            'id': tk.StringVar(value=data.get('id', str(uuid.uuid4()))),
            'title': tk.StringVar(value=data.get('title')),
            
            # NEW: Maximum Full Volume
            'max_volume_display': tk.StringVar(value=f"{max_vol_display:.2f}"),
            
            # These store the underlying KG value (the unit of persistence) and are bound to traces
            'tare_weight_kg': tk.StringVar(value=f"{empty_kg:.2f}"), 
            'total_weight_kg': tk.StringVar(value=f"{total_kg:.2f}"), 
            
            # These reflect the converted display values
            'starting_volume_display': tk.StringVar(value=f"{start_vol_display:.2f}"),
            # --- Current Volume uses LIVE Remaining Volume ---
            'current_volume_display': tk.StringVar(value=f"{remaining_display:.2f}"), 
            # ------------------------------------------------
            'current_dispensed_liters': tk.StringVar(value=f"{dispensed_l:.2f}"), # Only used for persistence
            
            # For tracking changes to enable the Cancel confirmation dialog
            'original_keg_data': data.copy()
        }
        
        # Temporary Entry storage variables for linking
        temp_vars['tare_entry'] = tk.StringVar(value=f"{empty_kg * weight_conversion:.2f}")
        temp_vars['total_entry'] = tk.StringVar(value=f"{total_kg * weight_conversion:.2f}")


        row_idx = tk.IntVar(value=0)

        # Helper function for adding fields (restored to prior correct state)
        def add_field(parent, label_text, var, unit="", row=None, readonly=False, is_volume=False, is_weight=False, is_title=False):
            # The 'row' parameter is explicitly provided by the caller now
            ttk.Label(parent, text=label_text, width=25, anchor="w").grid(row=row, column=0, padx=5, pady=5, sticky='w')
            
            if is_weight:
                # Determine the entry variable name based on the underlying KG variable's name
                base_name = var.get().split('_')[0] # 'tare' or 'total'
                display_var_name = f"{base_name}_entry"
                display_var = temp_vars[display_var_name]
            elif is_volume or not is_title:
                # For volume and non-title string/numeric fields, use the direct display variable
                display_var = var
            else:
                # For title (string), use its native var
                display_var = var

            # Set width based on field type
            widget_width = 30 if is_title else entry_width
            
            entry = ttk.Entry(parent, textvariable=display_var, width=widget_width, state=('readonly' if readonly else 'normal'))
            
            if is_weight:
                # Store the Entry widget object for the _save function
                temp_vars[var.get().replace('_weight_kg', '_entry_widget')] = entry
                
            entry.grid(row=row, column=1, sticky='ew', padx=5, pady=5)
            
            if is_weight and not readonly:
                 def update_kg_on_change(event, kg_var_name, entry_var):
                     try:
                         # Read displayed unit value
                         displayed_value = float(entry_var.get())
                         # Convert back to KG
                         kg_value = displayed_value / weight_conversion
                         # Update the underlying KG variable (which is traced for link calculation)
                         temp_vars[kg_var_name].set(f"{kg_value:.2f}")
                     except ValueError:
                         # Update with 0.00 to prevent crashing 
                         temp_vars[kg_var_name].set("0.00")
                         
                 # Bind focus out to ensure the underlying KG value is updated when user finishes typing.
                 entry.bind("<FocusOut>", lambda event, kg_var=var.get(), entry_var=display_var: update_kg_on_change(event, kg_var, entry_var))

            if unit: ttk.Label(parent, text=unit).grid(row=row, column=2, sticky='w', padx=2)
            row_idx.set(row + 1)
            return entry
        
        # --- End Helper ---

        form_frame.grid_columnconfigure(1, weight=1)
        
        # Row 1: Keg Title
        add_field(form_frame, "Keg Title:", temp_vars['title'], unit="", row=row_idx.get(), readonly=False, is_title=True); row_idx.set(row_idx.get())
        
        # Row 2: Maximum Full Volume
        add_field(form_frame, "Maximum Full Volume:", temp_vars['max_volume_display'], volume_unit, row=row_idx.get()); row_idx.set(row_idx.get())

        ttk.Separator(form_frame, orient='horizontal').grid(row=row_idx.get(), column=0, columnspan=3, sticky='ew', pady=5); row_idx.set(row_idx.get() + 1)
        
        # Separate frame for weight/volume linkage
        link_frame = ttk.Frame(form_frame); 
        link_frame.grid(row=row_idx.get(), column=0, columnspan=3, sticky='ew'); 
        # Configure the grid inside link_frame: Col 1 for the entry (fixed width), Col 2 for the unit, Col 3 for the button
        link_frame.grid_columnconfigure(1, weight=0, minsize=entry_width*8) 
        link_frame.grid_columnconfigure(2, weight=0) 
        link_frame.grid_columnconfigure(3, weight=1)
        row_idx.set(row_idx.get() + 1) # Advance the main form row index past the link_frame

        # Row 3: Tare Weight 
        tare_entry = add_field(link_frame, "Tare weight (empty weight):", tk.StringVar(value='tare_weight_kg'), weight_unit, row=0, is_weight=True)
        # Row 4: Starting Total Weight
        total_entry = add_field(link_frame, "Starting Total Weight:", tk.StringVar(value='total_weight_kg'), weight_unit, row=1, is_weight=True)
        
        # Row 5: Starting Volume (Readonly) --- LABEL FIX APPLIED HERE ---
        calc_vol_entry = add_field(link_frame, "Starting Volume:", temp_vars['starting_volume_display'], unit="", row=2, readonly=True, is_volume=True)
        
        # Force initial calculation and trace activation
        self._keg_edit_link_weight_to_volume(temp_vars, None)
        
        # --- Units for Calculated Starting Volume (placed in link_frame column 2) ---
        ttk.Label(link_frame, text=volume_unit).grid(row=2, column=2, sticky='w', padx=2)
        
        # Add the 'Use Starting Volume' button (correctly placed in the same row as the calculated volume)
        ttk.Button(link_frame, text="Use Starting Volume", width=18,
                   command=lambda v=temp_vars: v['current_volume_display'].set(v['starting_volume_display'].get())).grid(row=2, column=3, sticky='w', padx=5)
        
        # Row 6: Current (Remaining) Volume --- LABEL FIX APPLIED HERE ---
        current_vol_entry = add_field(link_frame, "Current (Remaining) Volume:", temp_vars['current_volume_display'], volume_unit, row=3, is_volume=True); 
        
        # Adjust the main row index to skip the rows used in the link_frame, then add the next separator
        row_idx.set(row_idx.get() + 1)
        ttk.Separator(form_frame, orient='horizontal').grid(row=row_idx.get(), column=0, columnspan=3, sticky='ew', pady=10); row_idx.set(row_idx.get() + 1)
        
        btns_frame = ttk.Frame(popup, padding="10"); btns_frame.pack(fill="x", side="bottom")
        
        # Save and Cancel buttons
        ttk.Button(btns_frame, text="Save", command=lambda p=popup: self._save_keg_definition(temp_vars, is_new, p, parent_popup)).pack(side="right", padx=5)
        ttk.Button(btns_frame, text="Cancel", command=lambda p=popup: self._keg_edit_check_cancel(temp_vars, p)).pack(side="right", padx=5)

        # NEW Help Button
        ttk.Button(btns_frame, text="Help", width=8, 
                   command=lambda: self._open_help_popup("keg_settings")).pack(side="right", padx=5)

        popup.update_idletasks()

    def _keg_edit_check_cancel(self, temp_vars, popup_window):
        """
        Implements the intermediary popup logic when the user cancels an edited keg.
        """
        
        # 1. Manually trigger FocusOut on all weight entries to ensure KG/Volume variables are up-to-date
        # This is critical for comparing the potentially unsaved state
        if 'tare_entry_widget' in temp_vars:
             temp_vars['tare_entry_widget'].event_generate('<FocusOut>')
        if 'total_entry_widget' in temp_vars:
             temp_vars['total_entry_widget'].event_generate('<FocusOut>')
             
        # 2. Re-calculate the current state based on StringVars
        display_units = self.settings_manager.get_display_units()
        volume_conversion = 1.0 if display_units == "metric" else LITERS_TO_GALLONS

        try:
            # Get the new calculated starting volume and current remaining volume
            tare_kg = float(temp_vars['tare_weight_kg'].get())
            total_kg = float(temp_vars['total_weight_kg'].get())
            max_vol_l = float(temp_vars['max_volume_display'].get()) / volume_conversion
            
            new_start_vol_l = self.settings_manager._calculate_volume_from_weight(total_kg, tare_kg)
            new_current_vol_l = float(temp_vars['current_volume_display'].get()) / volume_conversion
            new_dispensed_l = new_start_vol_l - new_current_vol_l
        except ValueError:
             # If inputs are invalid, treat as modified to avoid data loss
             is_modified = True
        else:
            # Get the original (saved) state from the internal dict
            original_data = temp_vars['original_keg_data']
            
            # Use a small tolerance for float comparison
            TOLERANCE = 0.01 
            
            # Check for modification
            is_modified = (
                abs(original_data.get('tare_weight_kg', 0.0) - tare_kg) > TOLERANCE or
                abs(original_data.get('starting_total_weight_kg', 0.0) - total_kg) > TOLERANCE or
                abs(original_data.get('calculated_starting_volume_liters', 0.0) - new_start_vol_l) > TOLERANCE or
                abs(original_data.get('current_dispensed_liters', 0.0) - new_dispensed_l) > TOLERANCE or
                abs(original_data.get('maximum_full_volume_liters', 0.0) - max_vol_l) > TOLERANCE or
                original_data.get('title', '') != temp_vars['title'].get().strip()
            )

        if not is_modified:
            # No changes, close safely
            popup_window.destroy()
            return

        # --- Show Confirmation Dialog ---
        popup_window.grab_release() 
        confirm_popup = tk.Toplevel(self.root)
        confirm_popup.title("Unsaved Changes")
        confirm_popup.geometry("450x150")
        confirm_popup.transient(popup_window)
        confirm_popup.grab_set()

        parent_x = popup_window.winfo_x(); parent_y = popup_window.winfo_y()
        parent_w = popup_window.winfo_width(); parent_h = popup_window.winfo_height()
        x = parent_x + (parent_w // 2) - (450 // 2)
        y = parent_y + (parent_h // 2) - (150 // 2)
        confirm_popup.geometry(f"+{x}+{y}")
        
        msg = "The keg data has been changed. Do you want to exit without saving the change, or return to the Edit Keg screen to save the change?"
        ttk.Label(confirm_popup, text=msg, wraplength=400, justify=tk.CENTER, padding=15).pack(expand=True, fill="both")

        btns_frame = ttk.Frame(confirm_popup, padding="10"); btns_frame.pack(fill="x", side="bottom")

        def exit_without_saving():
            confirm_popup.destroy()
            popup_window.destroy()

        def return_to_edit():
            confirm_popup.destroy()
            popup_window.grab_set()

        ttk.Button(btns_frame, text="Exit (Discard Changes)", command=exit_without_saving).pack(side="right", padx=5)
        ttk.Button(btns_frame, text="Return to Edit", command=return_to_edit).pack(side="right")
        
        confirm_popup.protocol("WM_DELETE_WINDOW", return_to_edit)

    def _save_keg_definition(self, temp_vars, is_new, popup_window, parent_popup):
        try:
            # Determine current units for parsing inputs
            display_units = self.settings_manager.get_display_units()
            volume_conversion = 1.0 if display_units == "metric" else LITERS_TO_GALLONS
            
            title = temp_vars['title'].get().strip(); 
            
            # --- Ensure FocusOut is triggered before reading the underlying KG variable ---
            if 'tare_entry_widget' in temp_vars:
                 temp_vars['tare_entry_widget'].event_generate('<FocusOut>')
            if 'total_entry_widget' in temp_vars:
                 temp_vars['total_entry_widget'].event_generate('<FocusOut>')
            
            # Retrieve the underlying KG values from their StringVars (which were updated by the trace handler)
            tare_kg = float(temp_vars['tare_weight_kg'].get())
            total_kg = float(temp_vars['total_weight_kg'].get())
            # Convert Max Volume back to Liters (stored unit)
            max_vol_l = float(temp_vars['max_volume_display'].get()) / volume_conversion
            
            # Retrieve display value for Current Volume, and convert back to Liters
            current_vol_display = temp_vars['current_volume_display'].get()
            current_vol_l = float(current_vol_display) / volume_conversion 
            
            # Recalculate starting volume in Liters (stored unit)
            start_vol_l = self.settings_manager._calculate_volume_from_weight(total_kg, tare_kg)
            
            # --- Validation ---
            if not title: messagebox.showerror("Input Error", "Keg Title cannot be empty.", parent=popup_window); return
            if not (tare_kg >= 0 and total_kg >= 0 and start_vol_l >= 0 and current_vol_l >= 0): 
                messagebox.showerror("Input Error", "All weights and volumes must be non-negative.", parent=popup_window); return
            if not (total_kg >= tare_kg):
                messagebox.showerror("Input Error", "Starting Total Weight must be greater than or equal to Tare Weight.", parent=popup_window); return
            
            # --- FIX: Replace 'new_start_vol_l' with 'start_vol_l' ---
            if not (current_vol_l <= start_vol_l + 0.01): # Add tolerance to ensure it's not greater
                messagebox.showerror("Input Error", f"Current Volume ({current_vol_l:.2f} L) cannot be greater than Calculated Starting Volume ({start_vol_l:.2f} L).", parent=popup_window); return
            # --------------------------------------------------------
            
            if not (max_vol_l >= 0):
                 messagebox.showerror("Input Error", "Maximum Full Volume must be non-negative.", parent=popup_window); return


            # Calculate the final dispensed volume to save (always in Liters)
            # Dispensed = Calculated Starting Volume - Current Remaining Volume
            current_dispensed_liters = start_vol_l - current_vol_l
            
            # Preserve existing dispensed volume logic:
            # If the keg is existing AND the starting volume hasn't changed AND the current volume hasn't changed, 
            # we should preserve the historical dispensed volume to maintain pour history integrity.
            existing_keg = self.settings_manager.get_keg_by_id(temp_vars['id'].get()) if not is_new else None
            
            final_dispensed_to_save = current_dispensed_liters

            if existing_keg:
                TOLERANCE = 0.01 
                # Check if the weight inputs were changed which would implicitly change the Calculated Starting Volume
                starting_vol_changed = abs(existing_keg.get('calculated_starting_volume_liters', 0.0) - start_vol_l) > TOLERANCE
                # Check if the current remaining volume was manually set/changed (by checking against the old remaining volume)
                old_remaining_l = max(0.0, existing_keg.get('calculated_starting_volume_liters', 0.0) - existing_keg.get('current_dispensed_liters', 0.0))
                current_vol_edited = abs(current_vol_l - old_remaining_l) > TOLERANCE
                
                # If neither the starting volume nor the current volume was changed, keep the old dispensed total.
                if not starting_vol_changed and not current_vol_edited:
                     final_dispensed_to_save = existing_keg.get('current_dispensed_liters', 0.0)

            # --- Create/Update Data Structure ---
            new_data = {
                "id": temp_vars['id'].get(), 
                "title": title, 
                "tare_weight_kg": tare_kg, # Use new key
                "starting_total_weight_kg": total_kg, 
                "maximum_full_volume_liters": max_vol_l, # Use new key
                "calculated_starting_volume_liters": start_vol_l, # Use new key
                "current_dispensed_liters": final_dispensed_to_save
            }
            keg_list = self.settings_manager.get_keg_definitions()
            
            if is_new: keg_list.append(new_data)
            else:
                found = False
                for i, k in enumerate(keg_list):
                    if k.get('id') == new_data['id']: 
                        keg_list[i] = new_data; 
                        found = True; 
                        break
                if not found: messagebox.showerror("Save Error", "Could not find the original keg to update.", parent=popup_window); return

            # SORT THE LIST BEFORE SAVING
            sorted_list = sorted(keg_list, key=lambda k: k.get('title', '').lower())
            
            self.settings_manager.save_keg_definitions(sorted_list)
            
            # CRITICAL: Reload initial volumes in SensorLogic
            if hasattr(self, 'sensor_logic') and self.sensor_logic and not self.sensor_logic.is_paused: 
                self.sensor_logic.force_recalculation()
            
            self._populate_keg_dropdowns(); 
            
            popup_window.destroy()
            if parent_popup and parent_popup.winfo_exists():
                 parent_popup.destroy() 
                 self._open_keg_settings_popup()
            
            print(f"UIManager: Keg '{title}' saved successfully.")

        except ValueError as e:
            # Catch errors from float conversion of the user input
            messagebox.showerror("Input Error", f"Invalid number for weight or volume input. Ensure values are numeric. Details: {e}", parent=popup_window)
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred while saving the keg: {e}", parent=popup_window)

    def _delete_keg_definition(self, keg_id, keg_title, parent_popup):
        if not messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete the keg '{keg_title}'? This will also re-assign any taps currently linked to it.", parent=parent_popup): return
            
        success, message = self.settings_manager.delete_keg_definition(keg_id)
        
        if success:
            # CRITICAL: Reload initial volumes in SensorLogic
            if hasattr(self, 'sensor_logic') and self.sensor_logic and not self.sensor_logic.is_paused: 
                self.sensor_logic.force_recalculation()
                
            self._populate_keg_dropdowns()
            self._refresh_ui_for_settings_or_resume() 

            parent_popup.destroy() 
            if self.settings_manager.get_keg_definitions(): 
                self._open_keg_settings_popup()
            else: 
                messagebox.showinfo("Keg Library Empty", "The Keg Library is now empty.", parent=self.root)
        else:
            messagebox.showerror("Delete Error", message, parent=parent_popup)


    # --- Flow Sensor Calibration Popup (NEW LIST VIEW) ---
    def _open_flow_calibration_popup(self):
         # UI mirrors the Keg Settings for consistent list view
         popup = tk.Toplevel(self.root)
         popup.title("Flow Sensor Calibration"); 
         popup.geometry("500x480"); 
         popup.transient(self.root); 
         popup.grab_set()

         main_frame = ttk.Frame(popup, padding="10"); 
         main_frame.pack(expand=True, fill="both")
         
         canvas = tk.Canvas(main_frame, borderwidth=0)
         v_scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
         scroll_frame = ttk.Frame(canvas)
         
         v_scrollbar.pack(side="right", fill="y"); 
         canvas.pack(side="left", fill="both", expand=True)
         canvas.configure(yscrollcommand=v_scrollbar.set)
         canvas_window = canvas.create_window((0, 0), window=scroll_frame, anchor="nw", width=480) 

         def on_frame_configure(event): canvas.configure(scrollregion=canvas.bbox("all"))
         scroll_frame.bind("<Configure>", on_frame_configure)
         def on_canvas_resize(event): canvas.itemconfig(canvas_window, width=event.width)
         canvas.bind('<Configure>', on_canvas_resize)

         # Grid column configuration for scroll_frame: Col 0 (Tap) expands, Col 1 (Button) fixed
         scroll_frame.grid_columnconfigure(0, weight=1); 
         scroll_frame.grid_columnconfigure(1, weight=0); 

         # --- Header Row ---
         header_frame = ttk.Frame(scroll_frame); 
         header_frame.grid(row=0, column=0, columnspan=2, sticky='ew', padx=5, pady=5)
         header_frame.grid_columnconfigure(0, weight=1); 
         header_frame.grid_columnconfigure(1, weight=0);
         
         ttk.Label(header_frame, text="Flow Sensor", font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=0, padx=5, sticky='w')
         ttk.Label(header_frame, text="Action", font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=1, sticky='e', padx=5)

         BG_EVEN = '#FFFFFF'; BG_ODD = '#F5F5F5' 

         # --- NEW: Get displayed taps count ---
         displayed_taps_count = self.settings_manager.get_displayed_taps()
         # -------------------------------------

         # --- Tap List Rows ---
         # MODIFIED: Loop only over displayed taps
         for i in range(displayed_taps_count):
             tap_name = f"Tap {i+1}"
             row = i + 1; bg_color = BG_ODD if i % 2 else BG_EVEN
             
             row_frame = tk.Frame(scroll_frame, bg=bg_color, relief='flat', bd=0); 
             row_frame.grid(row=row, column=0, columnspan=2, sticky='ew', pady=(1, 0))
             
             row_frame.grid_columnconfigure(0, weight=1) 
             row_frame.grid_columnconfigure(1, weight=0) 
             
             # Col 0: Tap Label
             ttk.Label(row_frame, text=tap_name, anchor='w', background=bg_color, 
                       padding=(5, 5)).grid(row=0, column=0, sticky='ew', padx=5)
             
             # Col 1: Calibrate Button
             ttk.Button(row_frame, text="Calibrate", width=12, 
                        command=lambda idx=i, p=popup: self._open_single_tap_calibration_popup(idx, p)).grid(row=0, column=1, padx=(5, 5), pady=2, sticky='e')

         # --- Footer Buttons ---
         buttons_frame = ttk.Frame(popup, padding="10"); 
         buttons_frame.pack(fill="x", side="bottom", pady=(10, 0))
         
         # Advanced Users button (left side) - RENAMED
         ttk.Button(buttons_frame, text="Manual Cal Factor - Expert Only", 
                    command=lambda p=popup: self._open_manually_enter_calibration_factor_popup(p)).pack(side="left", padx=5)

         ttk.Button(buttons_frame, text="Close", command=popup.destroy).pack(side="right", padx=5)
         
         # Help Button
         ttk.Button(buttons_frame, text="Help", width=8, 
                   command=lambda: self._open_help_popup("calibration")).pack(side="right", padx=5)
         
         scroll_frame.update_idletasks()

    # --- NEW: Live Data Callback for Calibration Popup (Exposed via UIManager) ---
    def _update_single_cal_data(self, flow_rate_lpm, dispensed_pour_liters):
        """
        Updates the live data fields on the single calibration popup if it is currently open.
        Note: This is designed to be called by UIManager from the sensor data queue.
        """
        if not self._single_cal_popup_window or not self._single_cal_popup_window.winfo_exists() or not self._single_cal_in_progress:
            return
        
        # 1. Update Measured Flow Rate (always L/min)
        self.single_cal_measured_flow_var.set(f"{flow_rate_lpm:.2f} L/min")

        # 2. Convert Liters to display units (ml or oz)
        unit_label = self.single_cal_unit_label.get()
        if unit_label == "ml":
            # Liters to ml
            pour_display_value = dispensed_pour_liters * 1000.0
        else:
            # Liters to oz
            pour_display_value = dispensed_pour_liters / OZ_TO_LITERS
            
        self.single_cal_measured_pour_var.set(f"{pour_display_value:.2f}")
        
    # --- END NEW LIVE DATA CALLBACK ---

    def _single_cal_stop(self):
        if not self._single_cal_in_progress: return
        
        self._single_cal_in_progress = False
        
        # Make the Volume Poured and Measured field READ-ONLY ('readonly') after stopping
        if hasattr(self, '_single_cal_volume_entry') and self._single_cal_volume_entry:
             self._single_cal_volume_entry.config(state='readonly')
        
        # In a real app, this would call sensor_logic to stop the flow cal mode for this tap
        if hasattr(self, 'sensor_logic') and self.sensor_logic:
            # stop_flow_calibration returns the total pulses and the final measured pour in Liters (sensor output)
            total_pulses, final_measured_liters = self.sensor_logic.stop_flow_calibration(self.single_cal_tap_index)
        else:
            total_pulses, final_measured_liters = 0, 0.0 # Mock data
            
        # 1. Get the value the user poured (in their unit, e.g., 1000 ml or 32 oz)
        try:
            target_pour_user_unit = float(self.single_cal_target_volume_var.get())
        except ValueError:
            target_pour_user_unit = 0.0 # Safety fallback
            
        # 2. Convert target pour to Liters (since K-factor is pulses/Liter)
        unit_label = self.single_cal_unit_label.get()
        if unit_label == "ml":
            target_pour_liters = target_pour_user_unit / 1000.0
        elif unit_label == "oz":
            target_pour_liters = target_pour_user_unit * OZ_TO_LITERS
        else:
            target_pour_liters = 0.0
            
        # --- NEW DEDUCTION LOGIC (Triggered by Stop Cal) ---
        deduct_volume = self.single_cal_deduct_volume_var.get()
        if deduct_volume and hasattr(self, 'sensor_logic') and self.sensor_logic and target_pour_liters > 0:
            
            # FIX: Deduct the KNOWN, MEASURED volume (target_pour_liters), not the sensor's output.
            self.sensor_logic.deduct_volume_from_keg(self.single_cal_tap_index, target_pour_liters)
            
            # Show message confirming deduction
            messagebox.showinfo("Inventory Deduction", 
                                f"Volume of {target_pour_liters:.2f} Liters deducted from the assigned keg inventory.", 
                                parent=self._single_cal_popup_window)
        # --- END NEW DEDUCTION LOGIC ---

        # 3. Calculate new K-factor (always using the user's ground truth volume)
        if target_pour_liters > 0 and total_pulses > 0:
            new_k_factor = total_pulses / target_pour_liters
            self._single_cal_calculated_new_factor = new_k_factor
            self._single_cal_last_pour = final_measured_liters # Keep sensor pour for tracking/diagnostic
            self.single_cal_new_factor_var.set(f"{new_k_factor:.2f}")
            self.single_cal_complete = True
            self.single_cal_set_btn.config(state=tk.NORMAL)
        else:
            self._single_cal_calculated_new_factor = None
            self._single_cal_last_pour = 0.0
            self.single_cal_new_factor_var.set("Error (0 Pulses or Target)")
            self.single_cal_complete = False
            self.single_cal_set_btn.config(state=tk.DISABLED)

        self.single_cal_start_btn.config(state=tk.NORMAL)
        self.single_cal_stop_btn.config(state=tk.DISABLED)
        
        print(f"Single Cal: Stopped. Pulses: {total_pulses}, Measured L: {final_measured_liters:.2f}")
        
    def _single_cal_check_close(self, popup_window):
        """
        Intermediary function called when the user attempts to close the calibration popup.
        Checks if a new factor was calculated but not set.
        """
        # STEP 1: If calibration was in progress, stop it gracefully.
        # This will calculate _single_cal_calculated_new_factor and enable the 'Set' button.
        if self._single_cal_in_progress and hasattr(self.sensor_logic, 'stop_flow_calibration'):
            # We call stop, which runs the calculation and updates the internal state.
            if self.single_cal_tap_index != -1:
                # Note: The result (pulses, pour) is discarded here, but the side effect
                # of updating _single_cal_calculated_new_factor and the UI happens in _single_cal_stop.
                # Call _single_cal_stop directly to ensure all state is updated.
                self._single_cal_stop() # <-- Call _single_cal_stop instead of stop_flow_calibration

        # STEP 2: Check if a new factor exists.
        # Check against the internal state variable, not the button state, as the button may have
        # been enabled by _single_cal_stop() which was just called in Step 1.
        if self._single_cal_calculated_new_factor is not None:
            # New factor calculated but not accepted (button is active)

            # Prevent closing the main popup until the choice is made
            popup_window.grab_release()

            confirm_popup = tk.Toplevel(self.root)
            confirm_popup.title("Unsaved Calibration")
            confirm_popup.geometry("450x150")
            confirm_popup.transient(popup_window)
            confirm_popup.grab_set()

            # Center the confirmation popup relative to the main one
            parent_x = popup_window.winfo_x(); parent_y = popup_window.winfo_y()
            parent_w = popup_window.winfo_width(); parent_h = popup_window.winfo_height()
            x = parent_x + (parent_w // 2) - (450 // 2)
            y = parent_y + (parent_h // 2) - (150 // 2)
            confirm_popup.geometry(f"+{x}+{y}")

            msg = "New cal factor has been calibrated. Do you want to set the new cal factor, or close without changing the cal factor?"
            ttk.Label(confirm_popup, text=msg, wraplength=400, justify=tk.CENTER, padding=15).pack(expand=True, fill="both")

            btns_frame = ttk.Frame(confirm_popup, padding="10"); btns_frame.pack(fill="x", side="bottom")

            # Define combined close action (saves, then closes both)
            def set_and_close():
                # Pass destroy_on_success=True to ensure the primary popup is destroyed
                self._single_cal_set(destroy_on_success=True, primary_popup=popup_window)
                confirm_popup.destroy()

            # Define discard action (just closes both)
            def discard_and_close():
                self._single_cal_calculated_new_factor = None # Discard the value
                self._single_cal_popup_window = None
                confirm_popup.destroy()
                popup_window.destroy()

            ttk.Button(btns_frame, text="Close (Discard Factor)", command=discard_and_close).pack(side="right", padx=5)
            ttk.Button(btns_frame, text="Set New Cal Factor", command=set_and_close).pack(side="right")

            # Prevent user from closing confirmation via window manager
            confirm_popup.protocol("WM_DELETE_WINDOW", lambda: None)

        else:
            # Safe to close. Perform final cleanup.
            self._single_cal_popup_window = None
            popup_window.destroy()
            
    def _open_single_tap_calibration_popup(self, tap_index, parent_popup):
        
        tap_name = f"Tap {tap_index + 1}"
        
        # Load current K-factors
        current_factors = self.settings_manager.get_flow_calibration_factors()
        current_k_factor = current_factors[tap_index]
        cal_settings = self.settings_manager.get_flow_calibration_settings()
        
        # Determine units for user entry
        display_units = self.settings_manager.get_display_units()
        unit_label = "ml" if display_units == "metric" else "oz"
        
        # Load variables for the single tap
        self.single_cal_tap_index = tap_index
        self.single_cal_unit_label.set(unit_label)
        
        # Load last used value for the user entry field (saved value is float)
        stored_value = cal_settings['to_be_poured']
        self.single_cal_target_volume_var.set(f"{stored_value:.0f}")

        # Set default deduction state (No = False)
        self.single_cal_deduct_volume_var.set(False)

        # Reset measured values
        self.single_cal_measured_flow_var.set("0.00 L/min")
        self.single_cal_measured_pour_var.set("0.00")
        
        # Initialize the new factor fields
        self.single_cal_current_factor_var.set(f"{current_k_factor:.2f}") # Show current factor
        self.single_cal_new_factor_var.set("") # Start blank
        self._single_cal_calculated_new_factor = None # Reset internal state

        # Reset calibration state
        self._single_cal_in_progress = False
        self._single_cal_complete = False
        self._single_cal_pulse_count = 0
        self._single_cal_last_pour = 0.0

        popup = tk.Toplevel(self.root)
        popup.title(f"Calibrate Flow Sensor: {tap_name}")
        popup.geometry("550x410") 
        popup.transient(self.root)
        popup.grab_set()
        
        self._single_cal_popup_window = popup 
        popup.protocol("WM_DELETE_WINDOW", lambda p=popup: self._single_cal_check_close(p))

        main_frame = ttk.Frame(popup, padding="15"); 
        main_frame.pack(expand=True, fill="both")
        
        # Labeling the selected tap (Tap N)
        ttk.Label(main_frame, text=f"Tap to Calibrate: {tap_name}", font=('TkDefaultFont', 12, 'bold')).pack(anchor='w', pady=(0, 10))

        form_frame = ttk.Frame(main_frame);
        form_frame.pack(fill="x", pady=10)
        
        # --- Column Weights (snug fit layout) ---
        form_frame.grid_columnconfigure(0, weight=1); 
        form_frame.grid_columnconfigure(1, weight=0); 
        form_frame.grid_columnconfigure(2, weight=0);
        # ----------------------------------------

        entry_width = 10 
        row = 0
        
        # NEW Row 1: Deduct Measured Volume from keg assigned to Tap N? No / Yes
        ttk.Label(form_frame, text=f"Deduct Measured Volume from keg assigned to {tap_name}?").grid(row=row, column=0, sticky='w', padx=5, pady=5)
        
        radio_frame = ttk.Frame(form_frame)
        radio_frame.grid(row=row, column=1, columnspan=2, sticky='w', padx=5, pady=5)
        
        tk.Radiobutton(radio_frame, text="No", variable=self.single_cal_deduct_volume_var, 
                       value=False).pack(side='left', padx=(0, 15))
        tk.Radiobutton(radio_frame, text="Yes", variable=self.single_cal_deduct_volume_var, 
                       value=True).pack(side='left')
        row += 1
        
        # Row 2: Volume Poured and Measured: [1000] [ml/oz]
        ttk.Label(form_frame, text="Volume Poured and Measured:").grid(row=row, column=0, sticky='w', padx=5, pady=5)
        
        # FIX 1: Set initial state to 'readonly' (inverted logic start)
        self._single_cal_volume_entry = ttk.Entry(form_frame, textvariable=self.single_cal_target_volume_var, 
                                                  width=entry_width, justify='center', state='readonly') 
        self._single_cal_volume_entry.grid(row=row, column=1, sticky='w', padx=5, pady=5)
        ttk.Label(form_frame, textvariable=self.single_cal_unit_label).grid(row=row, column=2, sticky='w')
        
        row += 1

        # Row 3: Measured Pour with Current Calibration: [0.00] [ml/oz]
        ttk.Label(form_frame, text="Measured Pour with Current Calibration:").grid(row=row, column=0, sticky='w', padx=5, pady=5)
        ttk.Label(form_frame, textvariable=self.single_cal_measured_pour_var, relief='sunken', anchor='w', width=entry_width).grid(row=row, column=1, sticky='w', padx=5, pady=5)
        ttk.Label(form_frame, textvariable=self.single_cal_unit_label).grid(row=row, column=2, sticky='w')
        row += 1

        # Row 4: Measured Flow Rate L/min: [0.00] [L/min]
        ttk.Label(form_frame, text="Measured Flow Rate L/min:").grid(row=row, column=0, sticky='w', padx=5, pady=5)
        ttk.Label(form_frame, textvariable=self.single_cal_measured_flow_var, relief='sunken', anchor='w', width=entry_width).grid(row=row, column=1, sticky='w', padx=5, pady=5)
        ttk.Label(form_frame, text="L/min").grid(row=row, column=2, sticky='w') 
        row += 1
        
        # Row 5: Current Calibration Factor
        ttk.Label(form_frame, text="Current Calibration Factor:").grid(row=row, column=0, sticky='w', padx=5, pady=5)
        ttk.Label(form_frame, textvariable=self.single_cal_current_factor_var, relief='sunken', anchor='w', width=entry_width).grid(row=row, column=1, sticky='w', padx=5, pady=5)
        row += 1
        
        # Row 6: New Calculated Calibration Factor
        ttk.Label(form_frame, text="New Calculated Calibration Factor:").grid(row=row, column=0, sticky='w', padx=5, pady=5)
        ttk.Label(form_frame, textvariable=self.single_cal_new_factor_var, relief='sunken', anchor='w', width=entry_width).grid(row=row, column=1, sticky='w', padx=5, pady=5)
        row += 1
        
        # Row 7: Buttons (Restored)
        button_frame = ttk.Frame(main_frame);
        button_frame.pack(fill="x", pady=20)
        
        self.single_cal_start_btn = ttk.Button(button_frame, text="Start Cal", width=12, command=self._single_cal_start)
        self.single_cal_start_btn.pack(side='left', padx=5, fill='x', expand=True)

        self.single_cal_stop_btn = ttk.Button(button_frame, text="Stop Cal", width=12, state=tk.DISABLED, command=self._single_cal_stop)
        self.single_cal_stop_btn.pack(side='left', padx=5, fill='x', expand=True)

        self.single_cal_set_btn = ttk.Button(button_frame, text="Set New Cal Factor", width=16, state=tk.DISABLED, command=lambda: self._single_cal_set(destroy_on_success=True))
        self.single_cal_set_btn.pack(side='left', padx=5, fill='x', expand=True)

        # Footer Button (Restored)
        buttons_frame = ttk.Frame(popup, padding="10"); 
        buttons_frame.pack(fill="x", side="bottom")
        
        ttk.Button(buttons_frame, text="Close", command=lambda p=popup: self._single_cal_check_close(p)).pack(side="right")
        
        # NEW Help Button
        ttk.Button(buttons_frame, text="Help", width=8, 
                   command=lambda: self._open_help_popup("calibration")).pack(side="right", padx=5)
        
    def _single_cal_start(self):
        # Validation
        try:
            target_vol_display = float(self.single_cal_target_volume_var.get())
            if target_vol_display <= 0:
                messagebox.showerror("Input Error", "Target volume must be a positive number.", parent=self.single_cal_start_btn.winfo_toplevel())
                return
        except ValueError:
            messagebox.showerror("Input Error", "Target volume must be a valid number.", parent=self.single_cal_start_btn.winfo_toplevel())
            return
            
        if self._single_cal_in_progress: return
        
        # Save the current target volume to settings immediately
        self.settings_manager.save_flow_calibration_settings(to_be_poured_value=target_vol_display)
        
        self._single_cal_in_progress = True
        self._single_cal_complete = False
        
        # NEW: Clear the New Calculated Calibration Factor field and internal state
        self.single_cal_new_factor_var.set("")
        self._single_cal_calculated_new_factor = None
        
        self.single_cal_start_btn.config(state=tk.DISABLED)
        self.single_cal_stop_btn.config(state=tk.NORMAL)
        self.single_cal_set_btn.config(state=tk.DISABLED)
        
        # FIX 2: Make the Volume Poured and Measured field EDITABLE ('normal') once calibration starts
        if hasattr(self, '_single_cal_volume_entry') and self._single_cal_volume_entry:
             self._single_cal_volume_entry.config(state='normal')
        
        # Reset measured values on UI to 0.00
        self.single_cal_measured_flow_var.set("0.00 L/min")
        self.single_cal_measured_pour_var.set("0.00")
        
        # In a real app, this would call sensor_logic to start the flow cal mode for this tap.
        if hasattr(self, 'sensor_logic') and self.sensor_logic:
            self.sensor_logic.start_flow_calibration(self.single_cal_tap_index, self.single_cal_target_volume_var.get())
            
        print(f"Single Cal: Started for Tap {self.single_cal_tap_index + 1} with target {target_vol_display}")

    # MODIFIED: Added parameter for the deduction flag
    def _single_cal_set(self, destroy_on_success=False, primary_popup=None):
        
        # Check against the internal storage, not the UI field
        if self._single_cal_calculated_new_factor is None:
            # Check if button state matches internal state
            if self.single_cal_set_btn.cget('state') == tk.NORMAL:
                messagebox.showwarning("Calibration", "Please perform a full Start Cal / Stop Cal sequence first.", parent=self.single_cal_set_btn.winfo_toplevel() or primary_popup)
            return

        new_k_factor = self._single_cal_calculated_new_factor
        
        try:
            target_pour_str = self.single_cal_target_volume_var.get()
            target_pour_display_unit = float(target_pour_str)
            
            # DEDUCTION LOGIC REMOVED: It is now handled in _single_cal_stop()
            # The deducted_liters variable is no longer needed here.

            # 1. Save the new factor
            factors = self.settings_manager.get_flow_calibration_factors()
            factors[self.single_cal_tap_index] = new_k_factor
            self.settings_manager.save_flow_calibration_factors(factors)
            
            # 2. Save the last used 'to be poured' value
            self.settings_manager.save_flow_calibration_settings(to_be_poured_value=target_pour_display_unit)
            
            # 3. Update the 'Current Calibration Factor' display
            self.single_cal_current_factor_var.set(f"{new_k_factor:.2f}")
            
            # 4. Success message (Removed deduction information)
            messagebox.showinfo("Calibration Success", 
                                f"Tap {self.single_cal_tap_index + 1}: New Calibration Factor (K) saved: {new_k_factor:.2f} pulses/Liter.", 
                                parent=self.single_cal_set_btn.winfo_toplevel() or primary_popup)
            
            # 5. Disable button
            self.single_cal_set_btn.config(state=tk.DISABLED)
            
            # 6. Clear the new factor UI and internal state
            self.single_cal_new_factor_var.set("")
            self._single_cal_calculated_new_factor = None
            self._single_cal_complete = False # Clear the completed state
            
            # 7. Force UI refresh
            if hasattr(self, 'sensor_logic') and self.sensor_logic:
                 # This reload will show the new K-Factor and the volume after deduction (if it occurred in _single_cal_stop)
                 self.sensor_logic.force_recalculation()
                 
            # 8. Close the single calibration popup if requested (from the close check dialog)
            if destroy_on_success and primary_popup and primary_popup.winfo_exists():
                 self._single_cal_popup_window = None # Clear reference before destroying
                 primary_popup.destroy()
                 
        except ValueError:
            messagebox.showerror("Error", "Calibration values are invalid.", parent=self.single_cal_set_btn.winfo_toplevel() or primary_popup)
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred: {e}", parent=self.single_cal_set_btn.winfo_toplevel() or primary_popup)
            
    def _open_manually_enter_calibration_factor_popup(self, parent_popup):
        # The parent_popup is the main Flow Sensor Calibration screen
        
        # --- NEW: Get displayed taps count ---
        displayed_taps_count = self.settings_manager.get_displayed_taps()
        # -------------------------------------
        
        # Load current factors and notes for display
        factors = self.settings_manager.get_flow_calibration_factors()
        cal_settings = self.settings_manager.get_flow_calibration_settings()
        notes = cal_settings['notes']
        
        # Load vars for the popup - only reset for the displayed taps
        # MODIFIED: Only loop over displayed_taps_count
        for i in range(displayed_taps_count):
            self.flow_cal_current_factors[i].set(f"{factors[i]:.2f}")
            self.flow_cal_new_factor_entries[i].set("") # Clear entry field on open
        self.flow_cal_notes_var.set(notes)

        popup = tk.Toplevel(self.root)
        popup.title("Manually Enter Calibration Factor")
        # --- FIX: Reduced vertical size for visibility of Close button ---
        popup.geometry("550x450") 
        # -----------------------------------------------------------------
        popup.transient(self.root)
        popup.grab_set()

        main_frame = ttk.Frame(popup, padding="10"); 
        main_frame.pack(expand=True, fill="both")

        # --- Table Headers (Fixed layout) ---
        header_frame = ttk.Frame(main_frame);
        header_frame.pack(fill="x", pady=(0, 5))
        
        header_frame.grid_columnconfigure(0, weight=1, minsize=80)  # Flow Sensor
        header_frame.grid_columnconfigure(1, weight=1, minsize=100) # Current Cal Factor
        header_frame.grid_columnconfigure(2, weight=1, minsize=100) # New Cal Factor
        header_frame.grid_columnconfigure(3, weight=1, minsize=120) # Button
        
        ttk.Label(header_frame, text="Flow Sensor", font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=0, sticky='w', padx=5)
        ttk.Label(header_frame, text="Cal Factor", font=('TkDefaultFont', 9, 'bold')).grid(row=0, column=1, sticky='ew')
        ttk.Label(header_frame, text="New Cal Factor", font=('TkDefaultFont', 9, 'bold')).grid(row=0, column=2, sticky='ew')
        # ttk.Label(header_frame, text="(button)", font=('TkDefaultFont', 9, 'bold')).grid(row=0, column=3, sticky='ew')

        # --- Scrollable Table Rows ---
        # Nested frame for scrollable content only, excluding the Notes area
        table_container = ttk.Frame(main_frame)
        table_container.pack(fill="x", expand=False)
        
        canvas = tk.Canvas(table_container, borderwidth=0, height=250) # Fixed height for the rows
        v_scrollbar = ttk.Scrollbar(table_container, orient="vertical", command=canvas.yview)
        scroll_frame = ttk.Frame(canvas)
        
        v_scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="x", expand=True)
        canvas.configure(yscrollcommand=v_scrollbar.set)
        canvas_window = canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        
        def on_canvas_resize(event): canvas.itemconfig(canvas_window, width=event.width)
        canvas.bind('<Configure>', on_canvas_resize)
        
        scroll_frame.grid_columnconfigure(0, weight=1, minsize=80)
        scroll_frame.grid_columnconfigure(1, weight=1, minsize=100)
        scroll_frame.grid_columnconfigure(2, weight=1, minsize=100)
        scroll_frame.grid_columnconfigure(3, weight=1, minsize=120)

        # MODIFIED: Only loop over displayed_taps_count
        for i in range(displayed_taps_count):
             row_idx = i
             
             ttk.Label(scroll_frame, text=f"Tap {i+1}").grid(row=row_idx, column=0, sticky='w', padx=5, pady=2)
             
             # Current Cal Factor (Display only)
             ttk.Label(scroll_frame, textvariable=self.flow_cal_current_factors[i], anchor='center', relief='sunken').grid(row=row_idx, column=1, sticky='ew', padx=5)

             # New Cal Factor (User Entry)
             ttk.Entry(scroll_frame, textvariable=self.flow_cal_new_factor_entries[i], width=12, justify='center').grid(row=row_idx, column=2, sticky='ew', padx=5)
             
             # Set New Factor Button
             ttk.Button(scroll_frame, text="Set New Factor", 
                        command=lambda idx=i, p=popup: self._set_new_calibration_factor(idx, p)).grid(row=row_idx, column=3, sticky='ew', padx=5)
        
        scroll_frame.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))

        # --- Notes Area ---
        notes_frame = ttk.Frame(main_frame); 
        # Pack below the table container, allow it to expand for the remaining space
        notes_frame.pack(fill="both", expand=True, pady=(5, 5))
        ttk.Label(notes_frame, text="Notes: (user-editable notes area)").pack(anchor='w')
        
        # Height set to 3 to save vertical space
        notes_text_widget = tk.Text(notes_frame, height=3, wrap=tk.WORD, relief='sunken', borderwidth=1)
        notes_text_widget.pack(fill="both", expand=True, pady=(2, 0))
        
        # Populate Text widget from StringVar
        notes_text_widget.insert(tk.END, self.flow_cal_notes_var.get())

        # --- Footer Buttons ---
        buttons_frame = ttk.Frame(popup, padding="10"); buttons_frame.pack(fill="x", side="bottom")
        
        # Close button calls a save method to persist notes
        ttk.Button(buttons_frame, text="Close", 
                   command=lambda p=popup, t=notes_text_widget: self._close_and_save_manual_cal_popup(p, t)).pack(side="right", padx=5)

        # NEW Help Button
        ttk.Button(buttons_frame, text="Help", width=8,
                   command=lambda: self._open_help_popup("calibration")).pack(side="right", padx=5)


    def _set_new_calibration_factor(self, tap_index, popup_window):
        new_factor_str = self.flow_cal_new_factor_entries[tap_index].get().strip()
        
        try:
            new_factor = float(new_factor_str)
            if new_factor <= 0:
                messagebox.showerror("Input Error", "Calibration factor must be a positive number.", parent=popup_window)
                return
            
            # 1. Update the list of factors
            factors = self.settings_manager.get_flow_calibration_factors()
            factors[tap_index] = new_factor
            
            # 2. Save the new factors list
            self.settings_manager.save_flow_calibration_factors(factors)
            
            # 3. Update the Current Cal Factor display on the popup
            self.flow_cal_current_factors[tap_index].set(f"{new_factor:.2f}")
            
            # 4. Clear the new factor entry field (as per implementation note)
            self.flow_cal_new_factor_entries[tap_index].set("")
            
            # 5. Force SensorLogic to update its factors
            if hasattr(self, 'sensor_logic') and self.sensor_logic:
                self.sensor_logic.force_recalculation()
                
            messagebox.showinfo("Success", f"Tap {tap_index + 1}: New Calibration Factor saved: {new_factor:.2f}.", parent=popup_window)
            
        except ValueError:
            messagebox.showerror("Input Error", "Calibration factor must be a valid number.", parent=popup_window)

    def _close_and_save_manual_cal_popup(self, popup_window, notes_text_widget):
        # 1. Get notes content
        new_notes = notes_text_widget.get("1.0", tk.END).strip()
        
        # 2. Save notes (only the notes value)
        self.settings_manager.save_flow_calibration_settings(notes=new_notes)
        
        # 3. Destroy popup
        popup_window.destroy()
        
    # --- System Settings Popup Logic (MODIFIED: Added Pour Volume) ---
    
    def _open_system_settings_popup(self, *args, **kwargs):
        # Re-implemented to avoid repeating the long function block.
        # Functionality remains the same as the prior block in my last response.
        popup = tk.Toplevel(self.root); popup.title("System Settings"); popup.geometry("450x450"); popup.transient(self.root); popup.grab_set()
        
        form_frame = ttk.Frame(popup, padding="10"); form_frame.pack(expand=True, fill="both")
        
        pour_settings = self.settings_manager.get_pour_volume_settings()
        self.system_settings_pour_ml_var.set(str(pour_settings['metric_pour_ml']))
        self.system_settings_pour_oz_var.set(str(pour_settings['imperial_pour_oz']))

        row_idx = 0
        
        ttk.Label(form_frame, text="Main Display Mode:").grid(row=row_idx, column=0, padx=5, pady=5, sticky="w")
        ui_mode_options = ["Full (1920x1080 display)", "Compact (800x600 display)"]
        current_ui_mode = self.settings_manager.get_ui_mode()
        display_value = ui_mode_options[0] if current_ui_mode == "full" else ui_mode_options[1]
        self.system_settings_ui_mode_var.set(display_value)
        ttk.Combobox(form_frame, textvariable=self.system_settings_ui_mode_var, values=ui_mode_options, state="readonly", width=25).grid(row=row_idx, column=1, padx=5, pady=5, sticky="ew"); row_idx += 1
        
        ttk.Label(form_frame, text="Volume Display Units:").grid(row=row_idx, column=0, padx=5, pady=5, sticky="w")
        unit_options = ["Metric (liters/kilograms)", "US Imperial (gallons/pounds)"]
        current_units_setting = self.settings_manager.get_display_units()
        display_value = unit_options[0] if current_units_setting == "metric" else unit_options[1]
            
        self.system_settings_unit_var.set(display_value)
        
        unit_dropdown = ttk.Combobox(form_frame, textvariable=self.system_settings_unit_var, values=unit_options, state="readonly", width=25)
        unit_dropdown.grid(row=row_idx, column=1, padx=5, pady=5, sticky="ew"); row_idx += 1
        unit_dropdown.bind("<<ComboboxSelected>>", lambda event: self._update_conditional_threshold_units())
        
        ttk.Label(form_frame, text="Taps to Display:").grid(row=row_idx, column=0, padx=5, pady=5, sticky="w")
        tap_count_options = [str(i) for i in range(1, self.num_sensors + 1)]
        self.system_settings_taps_var.set(str(self.settings_manager.get_displayed_taps()))
        ttk.Combobox(form_frame, textvariable=self.system_settings_taps_var, values=tap_count_options, state="readonly", width=5).grid(row=row_idx, column=1, padx=5, pady=5, sticky="w"); row_idx += 1
        
        if IS_RASPBERRY_PI_MODE:
            self.system_settings_autostart_var.set(self.settings_manager.get_autostart_enabled())
            ttk.Checkbutton(form_frame, 
                            text="Autostart KegLevel Monitor on Raspberry Pi startup/reboot", 
                            variable=self.system_settings_autostart_var).grid(row=row_idx, column=0, columnspan=2, padx=5, pady=5, sticky="w"); row_idx += 1
            
            self.system_settings_launch_workflow_var.set(self.settings_manager.get_launch_workflow_on_start())
            ttk.Checkbutton(form_frame, 
                            text="Launch KegLevel Workflow when KegLevel Monitor is started", 
                            variable=self.system_settings_launch_workflow_var).grid(row=row_idx, column=0, columnspan=2, padx=5, pady=5, sticky="w"); row_idx += 1

        ttk.Separator(form_frame, orient='horizontal').grid(row=row_idx, column=0, columnspan=2, sticky='ew', pady=10); row_idx += 1
        
        ttk.Label(form_frame, text="Pour Volume", font=('TkDefaultFont', 10, 'bold')).grid(row=row_idx, column=0, columnspan=2, pady=(0, 5), sticky="w"); row_idx += 1

        metric_pour_frame = ttk.Frame(form_frame); metric_pour_frame.grid(row=row_idx, column=0, columnspan=2, sticky='ew'); 
        ttk.Label(metric_pour_frame, text="Metric Pour Size (ml):", width=20, anchor="w").pack(side="left", padx=(5, 5), pady=5, anchor="w")
        ttk.Entry(metric_pour_frame, textvariable=self.system_settings_pour_ml_var, width=10).pack(side="left", padx=(0, 5), pady=5)
        ttk.Label(metric_pour_frame, text="ml").pack(side="left", padx=(0, 5), pady=5)
        row_idx += 1
        
        imperial_pour_frame = ttk.Frame(form_frame); imperial_pour_frame.grid(row=row_idx, column=0, columnspan=2, sticky='ew'); 
        ttk.Label(imperial_pour_frame, text="Imperial Pour Size (oz):", width=20, anchor="w").pack(side="left", padx=(5, 5), pady=5, anchor="w")
        ttk.Entry(imperial_pour_frame, textvariable=self.system_settings_pour_oz_var, width=10).pack(side="left", padx=(0, 5), pady=5)
        ttk.Label(imperial_pour_frame, text="oz (US Fluid)").pack(side="left", padx=(0, 5), pady=5)
        row_idx += 1

        ttk.Separator(form_frame, orient='horizontal').grid(row=row_idx, column=0, columnspan=2, sticky='ew', pady=10); row_idx += 1
        
        ttk.Label(form_frame, text="Temperature Sensor Assignment", font=('TkDefaultFont', 10, 'bold')).grid(row=row_idx, column=0, columnspan=2, pady=(0, 5), sticky="w"); row_idx += 1
        
        available_sensors = []
        if hasattr(self, 'temp_logic') and self.temp_logic: available_sensors = self.temp_logic.detect_ds18b20_sensors()
        sensor_options = available_sensors if available_sensors else ["No sensors found"]

        ttk.Label(form_frame, text="Ambient Temp Sensor:").grid(row=row_idx, column=0, padx=5, pady=5, sticky="w")
        self.sensor_ambient_var.set(self.settings_manager.get_system_settings().get('ds18b20_ambient_sensor', ''))
        ttk.Combobox(form_frame, textvariable=self.sensor_ambient_var, values=sensor_options, state="readonly", width=30).grid(row=row_idx, column=1, padx=5, pady=5, sticky="ew"); row_idx += 1

        form_frame.grid_columnconfigure(1, weight=1)

        buttons_frame = ttk.Frame(popup, padding="10"); buttons_frame.pack(fill="x", side="bottom")
        ttk.Button(buttons_frame, text="Save", command=lambda p=popup: self._save_system_settings(p)).pack(side="right", padx=5)
        ttk.Button(buttons_frame, text="Cancel", command=popup.destroy).pack(side="right", padx=5)
        # NEW HELP BUTTON
        ttk.Button(buttons_frame, text="Help", width=8,
                   command=lambda: self._open_help_popup("system_settings")).pack(side="right", padx=5)
        
        popup.update_idletasks(); popup.geometry(f"{popup.winfo_width()}x{popup.winfo_height()}")

    def _save_system_settings(self, popup_window):
        selected_unit_display = self.system_settings_unit_var.get()
        
        # --- Save Pour Volumes First with Validation ---
        try:
            new_pour_ml = int(self.system_settings_pour_ml_var.get())
            new_pour_oz = int(self.system_settings_pour_oz_var.get())
            if new_pour_ml <= 0 or new_pour_oz <= 0:
                 messagebox.showerror("Input Error", "Pour volume must be a positive whole number (ml and oz).", parent=popup_window)
                 return
            self.settings_manager.save_pour_volume_settings(new_pour_ml, new_pour_oz)
        except ValueError:
            messagebox.showerror("Input Error", "Pour volume fields must be valid whole numbers.", parent=popup_window)
            return
        
        # --- Unit and Mode Settings ---
        if selected_unit_display == "US Imperial (gallons/pounds)":
            new_unit_setting = "imperial"
        elif selected_unit_display == "Metric (liters/kilograms)":
            new_unit_setting = "metric"
        else:
            new_unit_setting = "imperial"
        
        selected_ui_mode_display = self.system_settings_ui_mode_var.get()
        new_ui_mode_setting = "full" if "Full" in selected_ui_mode_display else "lite"
        
        new_ambient_sensor_id = self.sensor_ambient_var.get()
        new_autostart_enabled = self.system_settings_autostart_var.get()
        new_launch_workflow_on_start = self.system_settings_launch_workflow_var.get()
        
        # Save display units (needed before refreshing UI)
        self.settings_manager.save_display_units(new_unit_setting)
        
        self.settings_manager.save_ui_mode(new_ui_mode_setting) 
        self.settings_manager.set_ds18b20_ambient_sensor(new_ambient_sensor_id)
        
        old_autostart_enabled = self.settings_manager.get_autostart_enabled()
        self.settings_manager.save_autostart_enabled(new_autostart_enabled)
        
        # --- CRITICAL FIX: Calculate and pass app_root_dir to manage_autostart_file ---
        if IS_RASPBERRY_PI_MODE and old_autostart_enabled != new_autostart_enabled:
            # 1. Get the base directory (~/keglevel/src/)
            app_src_dir = self.settings_manager.get_base_dir()
            # 2. Navigate up to the application root (~/keglevel/)
            app_root_dir = os.path.join(app_src_dir, "..")
            
            action = 'add' if new_autostart_enabled else 'remove'
            # PASS THE APPLICATION ROOT PATH
            manage_autostart_file(action, app_root_dir)
        
        self.settings_manager.save_launch_workflow_on_start(new_launch_workflow_on_start)
        
        try:
            new_displayed_taps = int(self.system_settings_taps_var.get())
            self.settings_manager.save_displayed_taps(new_displayed_taps)
            
            # CRITICAL: Force a full UI refresh after saving pour volumes, units, and taps
            self._refresh_ui_for_settings_or_resume()
            
            if hasattr(self, 'temp_logic') and self.temp_logic:
                self.temp_logic.get_assigned_sensor() 
                
                if self.temp_logic.ambient_sensor and self.temp_logic.ambient_sensor != 'unassigned':
                    temp_f = self.temp_logic.read_ambient_temperature()
                    
                    if temp_f is not None:
                        display_units = self.settings_manager.get_display_units()
                        if display_units == "imperial":
                            self.update_temperature_display(temp_f, "F")
                        else:
                            temp_c = (temp_f - 32) * (5/9)
                            self.update_temperature_display(temp_c, "C")
                        
                        self.temp_logic.last_known_temp_f = temp_f
                    else:
                        self.update_temperature_display(None, "No Sensor")
                else:
                    self.update_temperature_display(None, "No Sensor")
                    self.temp_logic.last_known_temp_f = None
                    
                if not self.temp_logic._running:
                    self.temp_logic.start_monitoring()

            print("UIManager: System settings saved.")
            popup_window.destroy()

            mode_changed = (new_ui_mode_setting != self.ui_mode)
            if mode_changed: self._open_restart_confirmation_dialog()
                 
        except ValueError: messagebox.showerror("Input Error", "Invalid number for taps display.", parent=popup_window)


    def _update_conditional_threshold_units(self):
        current_units = self.settings_manager.get_display_units()
        
        try:
            current_volume_value_str = self.msg_conditional_threshold_var.get()
            current_volume_value = float(current_volume_value_str) if current_volume_value_str else None
            current_low_temp_str = self.msg_conditional_low_temp_var.get()
            current_low_temp = float(current_low_temp_str) if current_low_temp_str else None
            current_high_temp_str = self.msg_conditional_high_temp_var.get()
            current_high_temp = float(current_high_temp_str) if current_high_temp_str else None
        except ValueError: current_volume_value = None; current_low_temp = None; current_high_temp = None

        if current_units == "imperial":
            self.msg_conditional_threshold_units_var.set("Gallons")
            if self.last_units_for_threshold == "metric" and current_volume_value is not None:
                self.msg_conditional_threshold_var.set(f"{current_volume_value * LITERS_TO_GALLONS:.2f}")

            self.msg_conditional_threshold_label_text.set("Notify when temperature is outside the range (low-high F)")
            if self.last_units_for_threshold == "metric":
                if current_low_temp is not None: self.msg_conditional_low_temp_var.set(f"{(current_low_temp * 9/5) + 32:.1f}")
                if current_high_temp is not None: self.msg_conditional_high_temp_var.set(f"{(current_high_temp * 9/5) + 32:.1f}")
        else:
            self.msg_conditional_threshold_units_var.set("Liters")
            if self.last_units_for_threshold == "imperial" and current_volume_value is not None:
                self.msg_conditional_threshold_var.set(f"{current_volume_value / LITERS_TO_GALLONS:.2f}")
            
            self.msg_conditional_threshold_label_text.set("Notify when temperature is outside the range (low-high C)")
            if self.last_units_for_threshold == "imperial":
                if current_low_temp is not None: self.msg_conditional_low_temp_var.set(f"{(current_low_temp - 32) * (5/9):.1f}")
                if current_high_temp is not None: self.msg_conditional_high_temp_var.set(f"{(current_high_temp - 32) * (5/9):.1f}")

        self.last_units_for_threshold = current_units

    def _toggle_email_fields_state(self, *args):
        """
        Enables or disables all fields based on the state of the three master checkboxes.
        """
        try:
            push_enabled = self.msg_push_enabled_var.get()
            cond_enabled = self.msg_conditional_enabled_var.get()
            req_enabled = self.status_req_enable_var.get()

            # 1. Outbound Alerts Section (Shared Recipient)
            # Enabled if EITHER push or conditional is ON
            outbound_active = push_enabled or cond_enabled
            outbound_state = 'normal' if outbound_active else 'disabled'
            
            if hasattr(self, 'shared_recipient_entry'):
                self.shared_recipient_entry.config(state=outbound_state)

            # 2. Push Specific
            push_state = 'normal' if push_enabled else 'disabled'
            if hasattr(self, 'freq_dropdown'):
                self.freq_dropdown.config(state=push_state)
                
            # 3. Conditional Specific
            cond_state = 'normal' if cond_enabled else 'disabled'
            if hasattr(self, 'cond_vol_entry'): self.cond_vol_entry.config(state=cond_state)
            if hasattr(self, 'cond_low_entry'): self.cond_low_entry.config(state=cond_state)
            if hasattr(self, 'cond_high_entry'): self.cond_high_entry.config(state=cond_state)

            # 4. Inbound Control Section
            req_state = 'normal' if req_enabled else 'disabled'
            if hasattr(self, 'req_sender_entry'):
                self.req_sender_entry.config(state=req_state)

            # 5. RPi Config Tab (Dependencies)
            
            # SMTP/Creds needed if ANY feature is ON
            smtp_needed = push_enabled or cond_enabled or req_enabled
            smtp_state = 'normal' if smtp_needed else 'disabled'
            
            if hasattr(self, 'rpi_email_entry'): self.rpi_email_entry.config(state=smtp_state)
            if hasattr(self, 'rpi_password_entry'): self.rpi_password_entry.config(state=smtp_state)
            if hasattr(self, 'smtp_server_entry'): self.smtp_server_entry.config(state=smtp_state)
            if hasattr(self, 'smtp_port_entry'): self.smtp_port_entry.config(state=smtp_state)
            
            # IMAP needed ONLY if Request is ON
            imap_state = 'normal' if req_enabled else 'disabled'
            
            if hasattr(self, 'imap_server_entry'): self.imap_server_entry.config(state=imap_state)
            if hasattr(self, 'imap_port_entry'): self.imap_port_entry.config(state=imap_state)

        except Exception as e:
            print(f"UI Info: State toggle failed (widget not ready?): {e}")
        
    def _save_message_settings(self, popup_window):
        try:
            # 1. Validate Ports
            push_on = self.msg_push_enabled_var.get()
            cond_on = self.msg_conditional_enabled_var.get()
            req_on = self.status_req_enable_var.get()
            
            smtp_port_val = self.msg_smtp_port_var.get()
            smtp_port_to_save = int(smtp_port_val) if smtp_port_val.strip() else ""
            
            if (push_on or cond_on or req_on) and smtp_port_to_save and not (0 < smtp_port_to_save <= 65535):
                messagebox.showerror("Input Error", "SMTP Port must be 1-65535.", parent=popup_window); return

            imap_port_val = self.status_req_imap_port_var.get()
            imap_port_to_save = int(imap_port_val) if imap_port_val.strip() else ""
            
            if req_on and imap_port_to_save and not (0 < imap_port_to_save <= 65535):
                messagebox.showerror("Input Error", "IMAP Port must be 1-65535.", parent=popup_window); return

            # 2. Parse Conditional Thresholds
            cond_threshold_val = self.msg_conditional_threshold_var.get()
            low_temp_val = self.msg_conditional_low_temp_var.get()
            high_temp_val = self.msg_conditional_high_temp_var.get()
            
            try:
                cond_threshold_display = float(cond_threshold_val) if cond_threshold_val else None
                low_temp_display = float(low_temp_val) if low_temp_val else None
                high_temp_display = float(high_temp_val) if high_temp_val else None
            except ValueError: 
                messagebox.showerror("Input Error", "Conditional Thresholds must be valid numbers.", parent=popup_window); return
            
            # Convert back to base units (Liters and F)
            cond_threshold_liters = cond_threshold_display
            if self.settings_manager.get_display_units() == "imperial" and cond_threshold_liters is not None:
                cond_threshold_liters = cond_threshold_liters / LITERS_TO_GALLONS

            low_temp_f = low_temp_display; high_temp_f = high_temp_display
            if self.settings_manager.get_display_units() == "metric":
                if low_temp_f is not None: low_temp_f = (low_temp_f * 9/5) + 32
                if high_temp_f is not None: high_temp_f = (high_temp_f * 9/5) + 32

            # 3. Construct Settings Objects
            
            # Push Settings: Map Boolean to "Email" or "None" for backward compatibility
            push_type = "Email" if push_on else "None"
            push_settings = {
                "notification_type": push_type, 
                "frequency": self.msg_frequency_var.get(),
                "server_email": self.msg_server_email_var.get().strip(), 
                "server_password": self.msg_server_password_var.get(),
                "email_recipient": self.msg_email_recipient_var.get().strip(), 
                "smtp_server": self.msg_smtp_server_var.get().strip(),
                "smtp_port": smtp_port_to_save,
                # SMS removed
                "sms_number": "", "sms_carrier_gateway": "" 
            }

            # Conditional Settings: Map Boolean to "Email" or "None"
            cond_type = "Email" if cond_on else "None"
            cond_settings = {
                "notification_type": cond_type, 
                "threshold_liters": cond_threshold_liters,
                "low_temp_f": low_temp_f, 
                "high_temp_f": high_temp_f,
                # Preserve existing state data
                "sent_notifications": self.settings_manager.get_conditional_notification_settings().get("sent_notifications", [False] * self.num_sensors),
                "temp_sent_timestamps": self.settings_manager.get_conditional_notification_settings().get("temp_sent_timestamps", []),
                "error_reported_times": self.settings_manager.get_conditional_notification_settings().get("error_reported_times", {})
            }
            
            # Status Request Settings
            status_settings = {
                "enable_status_request": req_on,
                "authorized_sender": self.status_req_sender_var.get().strip(),
                "rpi_email_address": self.msg_server_email_var.get().strip(),
                "rpi_email_password": self.msg_server_password_var.get(),
                "imap_server": self.status_req_imap_server_var.get().strip(),
                "imap_port": imap_port_to_save,
                "smtp_server": self.msg_smtp_server_var.get().strip(),
                "smtp_port": smtp_port_to_save
            }

            # 4. Save All
            self.settings_manager.save_push_notification_settings(push_settings)
            self.settings_manager.save_conditional_notification_settings(cond_settings)
            self.settings_manager.save_status_request_settings(status_settings)
            
            print("UIManager: Message settings saved.")
            
            # 5. Trigger Service Reschedule
            if hasattr(self, 'notification_service') and self.notification_service: 
                self.notification_service.force_reschedule()
                # Important: We also need to restart the status listener specifically because its enable flag changed
                # force_reschedule handles the push timer, but explicit listener restart is safer here.
                self.notification_service.stop_status_request_listener()
                self.notification_service.start_status_request_listener()

            if hasattr(self, 'sensor_logic') and self.sensor_logic: 
                self.sensor_logic.force_recalculation()

            popup_window.destroy()
            
        except ValueError: messagebox.showerror("Input Error", "Port must be a valid number.", parent=popup_window)
        except Exception as e: messagebox.showerror("Error", f"An unexpected error occurred while saving: {e}", parent=popup_window)

    # --- Temperature Log Popup Logic (Unchanged) ---

    def _execute_reset_log_and_refresh(self, popup_window):
        if messagebox.askyesno("Confirm Reset", "Are you sure you want to reset all temperature log data? This cannot be undone.", parent=popup_window):
            if hasattr(self, 'temp_logic') and self.temp_logic:
                self.temp_logic.reset_log()
                messagebox.showinfo("Log Reset", "Temperature log has been reset.", parent=popup_window)
                popup_window.destroy()
                self._open_temperature_log_popup() 
            else: messagebox.showerror("Error", "Temperature logic service is not available.", parent=popup_window)

    def _open_temperature_log_popup(self):
        popup = tk.Toplevel(self.root); popup.title("Temperature Log"); popup.geometry("450x250"); popup.transient(self.root); popup.grab_set()

        frame = ttk.Frame(popup, padding="15"); frame.pack(expand=True, fill="both")
        ttk.Label(frame, text="Temperature Records (High / Low / Average)", font=('TkDefaultFont', 12, 'bold')).pack(pady=(0, 15))

        headers_frame = ttk.Frame(frame); headers_frame.pack(fill='x')
        ttk.Label(headers_frame, text="Period", font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=0, padx=5, pady=2, sticky='w')
        ttk.Label(headers_frame, text="High", font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=1, padx=5, pady=2, sticky='w')
        ttk.Label(headers_frame, text="Low", font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=2, padx=5, pady=2, sticky='w')
        ttk.Label(headers_frame, text="Average", font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=3, padx=5, pady=2, sticky='w')

        log_data = self.temp_logic.get_temperature_log() if hasattr(self, 'temp_logic') and self.temp_logic else {}
        unit_char = "F" if self.settings_manager.get_display_units() == "imperial" else "C"

        periods = [("Day", log_data.get("day", {})), ("Week", log_data.get("week", {})), ("Month", log_data.get("month", {}))]

        for i, (period_name, data) in enumerate(periods):
            row = i + 1; ttk.Label(headers_frame, text=period_name).grid(row=row, column=0, padx=5, pady=2, sticky='w')
            high_val = f"{data.get('high'):.1f} {unit_char}" if data.get('high') is not None else "--.-"
            low_val = f"{data.get('low'):.1f} {unit_char}" if data.get('low') is not None else "--.-"
            avg_val = f"{data.get('avg'):.1f} {unit_char}" if data.get('avg') is not None else "--.-"
            ttk.Label(headers_frame, text=high_val).grid(row=row, column=1, padx=5, pady=2, sticky='w')
            ttk.Label(headers_frame, text=low_val).grid(row=row, column=2, padx=5, pady=2, sticky='w')
            ttk.Label(headers_frame, text=avg_val).grid(row=row, column=3, padx=5, pady=2, sticky='w')

        for col_idx in range(4): headers_frame.grid_columnconfigure(col_idx, weight=1)

        button_frame = ttk.Frame(popup); button_frame.pack(fill='x', pady=10)
        ttk.Button(button_frame, text="Reset Log", command=lambda p=popup: self._execute_reset_log_and_refresh(p)).pack(side='left', padx=10)
        ttk.Button(button_frame, text="Close", command=popup.destroy).pack(side='right', padx=10)

    # --- Reset to Defaults Popup Logic (Unchanged) ---
    
    def _open_reset_to_defaults_popup(self):
        popup = tk.Toplevel(self.root); popup.title("Reset All Settings"); popup.geometry("450x180"); popup.transient(self.root); popup.grab_set()

        main_frame = ttk.Frame(popup, padding="15"); main_frame.pack(expand=True, fill="both")

        message_text = ("Reset clears ALL settings including the SECURITY KEY, message settings, keg settings, "
                        "system settings, and the **entire Beverage Library**. ALL are reset to their default values.")
        ttk.Label(main_frame, text=message_text, wraplength=400, justify="left").pack(pady=(0, 20))

        buttons_frame = ttk.Frame(popup, padding="10"); buttons_frame.pack(fill="x", side="bottom")

        ttk.Button(buttons_frame, text="Cancel", command=popup.destroy).pack(side="right", padx=(10,0))
        ttk.Button(buttons_frame, text="Save (Reset)", command=lambda p=popup: self._execute_reset_to_defaults(p)).pack(side="right", padx=(0,10))

    def _execute_reset_to_defaults(self, popup_window):
        if not messagebox.askyesno("Confirm Reset",
                                   "Are you sure you want to reset ALL settings (including the Beverage Library) to their original defaults?\nThis action cannot be undone.",
                                   parent=popup_window): return

        print("UIManager: Executing reset to default settings...")
        
        autostart_was_enabled = self.settings_manager.get_autostart_enabled()
        if IS_RASPBERRY_PI_MODE and autostart_was_enabled:
            manage_autostart_file('remove')
        
        if self.settings_manager: self.settings_manager.reset_all_settings_to_defaults()

        self._load_initial_ui_settings()
        self._refresh_ui_for_settings_or_resume()

        if hasattr(self, 'notification_service') and self.notification_service: self.notification_service.force_reschedule()

        messagebox.showinfo("Settings Reset", "All settings have been reset to their default values.", parent=self.root)
        popup_window.destroy()

    # --- Wiring Diagram Popup Logic (Unchanged) ---
    def _open_wiring_diagram_popup(self):
        try:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            
            # --- REFACTOR: Look in 'assets' and use .gif extension ---
            image_path = os.path.join(base_dir, "assets", "wiring.gif")
            if not os.path.exists(image_path): 
                messagebox.showerror("Error", f"wiring.gif not found:\n{image_path}", parent=self.root)
                return
            # --- END REFACTOR ---
                
            popup = tk.Toplevel(self.root); popup.title("Wiring Diagram"); popup.transient(self.root)
            wiring_image_obj = tk.PhotoImage(file=image_path)
            image_label = ttk.Label(popup, image=wiring_image_obj); image_label.image = wiring_image_obj; image_label.pack(padx=20, pady=20)
            close_button_frame = ttk.Frame(popup); close_button_frame.pack(pady=(0, 10), fill='x')
            ttk.Button(close_button_frame, text="Close", command=popup.destroy).pack()
        except tk.TclError as e: 
            messagebox.showerror("Image Error", f"Could not load wiring.gif:\n{e}", parent=self.root)
        except FileNotFoundError: 
            messagebox.showerror("Error", f"wiring.gif FileNotFoundError. Expected at:\n{image_path}", parent=self.root)
        except Exception as e: 
            messagebox.showerror("Error", f"An unexpected error occurred while opening wiring diagram:\n{e}", parent=self.root)
            
    def _on_link_click(self, url):
        """
        Handles link clicks.
        - If url starts with 'section:', stays in the help window and loads that section.
        - Otherwise, opens in the default web browser.
        """
        if url.startswith("section:"):
            section_name = url.split(":", 1)[1]
            
            # We need to find the existing help text widget to update it
            # Since this method is bound to a specific text widget event, 
            # we normally wouldn't have reference to the popup window here easily 
            # without passing it through lambdas complexity.
            
            # SIMPLER APPROACH: Close current help and open new section
            # This is visually instantaneous.
            
            # Find the top-level help window (active window)
            top = self.root.focus_get().winfo_toplevel()
            if top:
                top.destroy()
                
            # Open the new section
            self.root.after(50, lambda: self._open_help_popup(section_name))
            
        else:
            try:
                webbrowser.open_new(url)
            except Exception as e:
                print(f"Error opening link: {e}")

    def _get_help_section(self, section_name):
        """
        Loads the consolidated help.txt file and extracts a specific section.
        Sections are defined by [SECTION: section_name].
        """
        try:
            # Path is src/assets/help.txt
            help_file_path = os.path.join(self.base_dir, "assets", "help.txt")
            
            with open(help_file_path, 'r', encoding='utf-8') as f:
                full_help_text = f.read()
            
            # Use regex to find the section
            # Pattern: [SECTION: section_name] ...content... [SECTION: ...or EOF
            # re.S (DOTALL) makes '.' match newlines
            pattern = re.compile(r'\[SECTION:\s*' + re.escape(section_name) + r'\](.*?)(?=\[SECTION:|\Z)', re.S)
            match = pattern.search(full_help_text)
            
            if match:
                return match.group(1).strip() # Return the content
            else:
                return f"## ERROR ##\nSection '[SECTION: {section_name}]' not found in help.txt."
                
        except FileNotFoundError:
            return "## ERROR ##\nConsolidated 'help.txt' file not found in assets folder."
        except Exception as e:
            return f"## ERROR ##\nAn error occurred loading the help file:\n{e}"

    def _create_formatted_help_popup(self, title, help_text):
        """
        Creates a new Toplevel window and populates it with formatted
        text parsed from the help_text string.
        """
        popup = tk.Toplevel(self.root)
        popup.title(title)
        popup.transient(self.root); popup.grab_set()
        
        try:
            default_font = tkfont.nametofont("TkDefaultFont")
            default_family = default_font.actual("family")
            default_size = default_font.actual("size")
        except:
            default_family = "TkDefaultFont"
            default_size = 10
        
        main_frame = ttk.Frame(popup, padding="10")
        main_frame.pack(fill="both", expand=True)
        main_frame.grid_rowconfigure(0, weight=1)
        main_frame.grid_columnconfigure(0, weight=1)
        
        scrollbar = ttk.Scrollbar(main_frame, orient='vertical')
        scrollbar.grid(row=0, column=1, sticky='ns')
        
        text_widget = tk.Text(main_frame, wrap='word', yscrollcommand=scrollbar.set, 
                              relief='sunken', borderwidth=1, padx=10, pady=10,
                              font=(default_family, default_size))
        text_widget.grid(row=0, column=0, sticky='nsew')
        scrollbar.config(command=text_widget.yview)

        # --- Define Formatting Tags ---
        text_widget.tag_configure("heading", font=(default_family, default_size + 2, 'bold', 'underline'), spacing1=5, spacing3=10)
        text_widget.tag_configure("bold", font=(default_family, default_size, 'bold'))
        text_widget.tag_configure("bullet", lmargin1=20, lmargin2=20, offset=10)
        text_widget.tag_configure("link", font=(default_family, default_size, 'underline'), foreground="blue")
        
        text_widget.config(state='normal')
        
        link_regex = r'\[(.*?)\]\((.*?)\)'
        bold_regex = r'(\*\*.*?\*\*)'
        link_count = 0
        
        # --- Helper function to parse bold/links within a line ---
        def parse_line_content(line_str, base_tags=()):
            """Parses a line for bold/links and inserts it."""
            parts = re.split(r'(\[.*?\]\(.*?\))', line_str) # Split by links
            
            nonlocal link_count
            
            for part in parts:
                link_match = re.match(link_regex, part)
                
                if link_match:
                    link_text = link_match.group(1)
                    link_url = link_match.group(2)
                    
                    tag_name = f"link_{link_count}"
                    link_count += 1
                    
                    all_tags = base_tags + (tag_name,)
                    
                    text_widget.tag_configure(tag_name, font=(default_family, default_size, 'underline'), foreground="blue")
                    text_widget.tag_bind(tag_name, "<Button-1>", lambda e, url=link_url: self._on_link_click(url))
                    text_widget.tag_bind(tag_name, "<Enter>", lambda e: text_widget.config(cursor="hand2"))
                    text_widget.tag_bind(tag_name, "<Leave>", lambda e: text_widget.config(cursor=""))
                    
                    text_widget.insert("end", link_text, all_tags)
                
                else:
                    bold_parts = re.split(bold_regex, part)
                    for bold_part in bold_parts:
                        if bold_part.startswith("**") and bold_part.endswith("**"):
                            all_tags = base_tags + ("bold",)
                            text_widget.insert("end", bold_part[2:-2], all_tags)
                        else:
                            text_widget.insert("end", bold_part, base_tags)
        # --- END Helper ---

        try:
            for line in help_text.strip().splitlines():
                line_stripped = line.strip()
                
                if line_stripped.startswith("##") and line_stripped.endswith("##"):
                    text_widget.insert("end", line_stripped[2:-2].strip() + "\n", "heading")
                
                elif line_stripped.startswith("* "):
                    text_widget.insert("end", "• ", ("bullet",)) 
                    parse_line_content(line_stripped[2:], base_tags=("bullet",))
                    text_widget.insert("end", "\n") 
                
                elif not line_stripped:
                    text_widget.insert("end", "\n")
                    
                else:
                    parse_line_content(line_stripped, base_tags=())
                    text_widget.insert("end", "\n") 
                    
        except Exception as e:
            text_widget.insert("end", f"An error occurred while parsing help text: {e}")
        
        text_widget.config(state='disabled') # Make read-only
        
        btn_frame = ttk.Frame(popup, padding=(10, 0, 10, 10))
        btn_frame.pack(fill="x", side="bottom")
        ttk.Button(btn_frame, text="Close", command=popup.destroy).pack(side="right")
        
        # Center using our standard logic
        popup.update_idletasks()
        popup.withdraw()
        self._center_popup(popup, 720, 550)

    def _open_help_popup(self, section_name="main"):
        """
        Loads the help text for a specific section. 
        Defaults to 'main' table of contents.
        """
        help_text = self._get_help_section(section_name)
        
        # Map internal section names to human-readable window titles
        titles = {
            "main": "KegLevel Monitor - Help",
            "keg_settings": "Help: Keg Settings",
            "beverage_library": "Help: Beverage Library",
            "notifications": "Help: Notifications",
            "calibration": "Help: Flow Calibration",
            "system_settings": "Help: System Settings",
            "workflow": "Help: Workflow",
            "temp_log": "Help: Temperature Log",
            "wiring": "Help: Wiring Diagram"
        }
        
        title = titles.get(section_name, "KegLevel Help")
        self._create_formatted_help_popup(title, help_text)
        
    # --- EULA / SUPPORT POPUP ---

    def _load_support_image(self):
        """Loads the QR code image and stores it."""
        if self.support_qr_image:
            return # Already loaded
            
        try:
            # base_dir is self.base_dir, which is ~/keglevel/src/
            # Path is now src/assets/support.gif
            image_path = os.path.join(self.base_dir, "assets", "support.gif")
            
            # Use tk.PhotoImage directly, which supports GIF natively
            self.support_qr_image = tk.PhotoImage(file=image_path)
            
        except FileNotFoundError:
            print("Error: support.gif image not found.")
            self.support_qr_image = None # Ensure it's None
        except tk.TclError as e:
            # This is the error tk.PhotoImage throws for bad files
            print(f"Error loading support.gif (is it a valid GIF?): {e}")
            self.support_qr_image = None
        except Exception as e:
            print(f"Error loading support image: {e}")
            self.support_qr_image = None
            
    def _center_popup(self, popup, width, height):
        """
        Centers the popup on the screen (monitor) to ensure stability 
        and prevent 'jumping' relative to the main window.
        """
        # Update idle tasks to ensure geometry calculations are accurate
        popup.update_idletasks()
        
        # Get Screen Dimensions
        screen_width = popup.winfo_screenwidth()
        screen_height = popup.winfo_screenheight()
        
        # Calculate Center X, Y
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        
        # Safety: Ensure we don't spawn off the top/left of the screen
        # We use 30 for Y to account for typical taskbars if the calculation yields 0
        x = max(0, x)
        y = max(30, y)
        
        # Apply geometry and reveal
        popup.geometry(f'{width}x{height}+{x}+{y}')
        popup.deiconify()

    def _open_support_popup(self, is_launch=False):
        """
        Displays the 'Support this App' popup, which includes the EULA.
        'is_launch=True' modifies behavior (e.g., forces modal).
        """
        popup = tk.Toplevel(self.root)
        popup.title("Support This App & EULA")
        
        # --- FIX: REMOVED popup.withdraw() ---
        
        # --- 1. Load Image ---
        self._load_support_image() # Load/check image

        # --- 2. Reset UI Variables ---
        
        # Pre-select "I agree" if previously agreed
        system_settings = self.settings_manager.get_system_settings()
        has_agreed = system_settings.get("eula_agreed", False)
        
        if has_agreed:
            self.eula_agreement_var.set(1) # 1 = agree
        else:
            self.eula_agreement_var.set(0) # 0 = unset
        
        # Load the saved setting for "show on launch"
        # The checkbox var is "Do not show", so its state is the *inverse*
        show_on_launch_setting = system_settings.get("show_eula_on_launch", True)
        self.show_eula_checkbox_var.set(not show_on_launch_setting)
        
        # --- 3. Build UI ---
        main_frame = ttk.Frame(popup, padding="15")
        main_frame.pack(fill="both", expand=True)

        # --- Top Section ---
        top_frame = ttk.Frame(main_frame)
        top_frame.pack(fill="x", pady=(0, 15))
        top_frame.grid_columnconfigure(0, weight=1) # Text column
        top_frame.grid_columnconfigure(1, weight=0) # Image column

        support_text = (
            "This App took hundreds of hours to develop, test, and optimize. "
            "Please consider supporting this App with a donation so continuous improvements "
            "can be made. If you wish to receive customer support via email, please "
            "make a reasonable donation in support of this App. Customer support "
            "requests without a donation may not be considered for response."
        )
        
        text_label = ttk.Label(top_frame, text=support_text, wraplength=520, justify="left")
        text_label.grid(row=0, column=0, sticky="nsew", padx=(0, 15))
        
        if self.support_qr_image:
            qr_label = ttk.Label(top_frame, image=self.support_qr_image)
            qr_label.grid(row=0, column=1, sticky="e")
        else:
            qr_placeholder = ttk.Label(top_frame, text="[support.gif Missing]", relief="sunken", padding=20)
            qr_placeholder.grid(row=0, column=1, sticky="e")
            
        # --- EULA Section ---
        eula_frame = ttk.LabelFrame(main_frame, text="End User License Agreement (EULA)", padding=10)
        eula_frame.pack(fill="both", expand=True, pady=(0, 15))
        
        eula_text_widget = scrolledtext.ScrolledText(eula_frame, height=10, wrap="word", relief="flat")
        eula_text_widget.pack(fill="both", expand=True)
        
        # 1. Define tags
        try:
            default_font = tkfont.nametofont("TkDefaultFont")
            bold_font = default_font.copy()
            bold_font.config(weight="bold")
            eula_text_widget.tag_configure("bold", font=bold_font)
        except:
            eula_text_widget.tag_configure("bold", font=('TkDefaultFont', 10, 'bold'))
        
        # 2. Insert content line by line, applying tags as we go
        eula_text_widget.config(state="normal") # Enable editing to insert text
        
        eula_text_widget.insert("end", "End User License Agreement (EULA)\n\n", "bold")
        
        eula_text_widget.insert("end", "1. Scope of Agreement\n", "bold")
        eula_text_widget.insert("end", (
            "This Agreement applies to the \"KegLevel Monitor\" software (hereafter \"this app\"). "
            "\"This app\" includes the main software program and all related software and hardware components, "
            "including commercially supplied, home-made, or independently supplied hardware "
            "and software components of any kind.\n\n"
        ))
        
        eula_text_widget.insert("end", "2. Acceptance of Responsibility\n", "bold")
        eula_text_widget.insert("end", (
            "By using this app, you, the user, accept all responsibility for any consequence or "
            "outcome arising from the use of, or inability to use, this app.\n\n"
        ))
        
        eula_text_widget.insert("end", "3. No Guarantee or Warranty\n", "bold")
        eula_text_widget.insert("end", (
            "This app is provided \"as is.\" It provides no guarantee of usefulness or fitness "
            "for any particular purpose. The app provides no warranty, expressed or implied. "
            "You use this app entirely at your own risk.\n"
        ))
        
        eula_text_widget.config(state="disabled") # Make read-only

        # --- Agreement Section ---
        agreement_frame = ttk.Frame(main_frame)
        agreement_frame.pack(fill="x")

        # Radio 1: Agree
        agree_rb = ttk.Radiobutton(agreement_frame, 
                                   text="I agree with the above End User License Agreement", 
                                   variable=self.eula_agreement_var, value=1)
        agree_rb.pack(anchor="w")
        agree_note = ttk.Label(agreement_frame, text="User may proceed to the app after closing this popup",
                               font=('TkDefaultFont', 8, 'italic'))
        agree_note.pack(anchor="w", padx=(20, 0), pady=(0, 5))

        # Radio 2: Disagree
        disagree_rb = ttk.Radiobutton(agreement_frame, 
                                     text="I do not agree with the above End User License Agreement", 
                                     variable=self.eula_agreement_var, value=2)
        disagree_rb.pack(anchor="w")
        disagree_note = ttk.Label(agreement_frame, text="User will exit the app after closing this popup",
                                 font=('TkDefaultFont', 8, 'italic'))
        disagree_note.pack(anchor="w", padx=(20, 0), pady=(0, 10))

        # --- Bottom Section (Checkbox & Close) ---
        bottom_frame = ttk.Frame(main_frame)
        bottom_frame.pack(fill="x", side="bottom")

        show_again_cb = ttk.Checkbutton(bottom_frame, 
                                        text="This popup can be found on the Settings & Info menu. Do not show this popup at launch again.",
                                        variable=self.show_eula_checkbox_var)
        show_again_cb.pack(anchor="w", pady=(0, 10))

        close_btn = ttk.Button(bottom_frame, text="Close", 
                               command=lambda: self._handle_support_popup_close(popup))
        close_btn.pack(side="right")

        # --- 4. Finalize Popup ---
        
        # --- THIS IS THE FIX ---
        # 1. Force Tkinter to calculate the window's required size
        popup.update_idletasks()
        
        # 2. Use a fixed width
        popup_width = 800
        # 3. Get the *actual calculated height*
        popup_height = popup.winfo_height()
        
        # 4. Call the helper function to center and reveal the popup
        self._center_popup(popup, popup_width, popup_height)
        # --- END FIX ---
        
        popup.resizable(False, False)
        
        # Force modal interaction if on launch
        if is_launch:
            popup.protocol("WM_DELETE_WINDOW", lambda: self._handle_support_popup_close(popup))
            popup.transient(self.root)
            popup.grab_set()
            self.root.wait_window(popup)
        else:
            popup.transient(self.root)
            popup.grab_set()
            
    def _handle_support_popup_close(self, popup):
        """Handles the logic for the 'Close' button on the Support/EULA popup."""
        
        if not popup.winfo_exists():
            return
        
        agreement_state = self.eula_agreement_var.get()
        do_not_show_checked = self.show_eula_checkbox_var.get()
        
        # --- THIS IS THE FIX ---
        # Get the *actual* system_settings dictionary from the settings manager,
        # not a copy from get_system_settings().
        try:
            system_settings = self.settings_manager.settings['system_settings']
        except KeyError:
            # Fallback in case settings are severely corrupted
            print("Error: 'system_settings' key missing from settings manager.")
            system_settings = self.settings_manager._get_default_system_settings()
        # --- END FIX ---
            
        settings_changed = False

        if agreement_state == 1: # "I agree"
            new_show_on_launch = not do_not_show_checked
            if system_settings.get("show_eula_on_launch") != new_show_on_launch:
                system_settings["show_eula_on_launch"] = new_show_on_launch
                settings_changed = True
            
            if not system_settings.get("eula_agreed"):
                system_settings["eula_agreed"] = True
                settings_changed = True
            
            if settings_changed:
                self.settings_manager._save_all_settings() # Save the modified dict
            
            popup.destroy()
            return

        elif agreement_state == 2: # "I do not agree"
            # Reset the "do not show" setting if they disagreed
            if do_not_show_checked:
                system_settings["show_eula_on_launch"] = True
                settings_changed = True
            
            if system_settings.get("eula_agreed"):
                system_settings["eula_agreed"] = False
                settings_changed = True
            
            if settings_changed:
                self.settings_manager._save_all_settings()
            
            popup.destroy()
            self._show_disagree_dialog()
            return
            
        else: # State is 0 (neither selected)
            if not popup.winfo_exists():
                return
            messagebox.showwarning("Agreement Required", 
                                   "You must select 'I agree' or 'I do not agree' to proceed.", 
                                   parent=popup)
            # Do not close the popup
            return

    def _show_disagree_dialog(self):
        """Shows the final confirmation dialog when user disagrees with EULA."""
        
        if messagebox.askokcancel("EULA Disagreement",
                                "You chose to not agree with the End User License Agreement, so the app will terminate when you click OK.\n\n"
                                "Click Cancel to return to the agreement or click OK to exit the app."):
            
            # User clicked OK (True) -> Terminate the app
            print("EULA Disagreement: User clicked OK. Terminating application.")
            
            # We must call the root's destroy method
            self.root.destroy()
            
        else:
            # User clicked Cancel (False) -> Re-open the EULA popup
            # Force it as a 'launch' popup to ensure it's modal
            self._open_support_popup(is_launch=True)

    
